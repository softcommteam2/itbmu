INSERT INTO tbl_subscribe(name, email, createdate) VALUES("su su","susumyaing1989@gmail.com","2017-01-27"),
("su su","susumyaing1989@gmail.com","2017-01-27"),
("su su","susumyaing1989@gmail.com","2017-01-27"),
("su su","susumyaing1989@gmail.com","2017-01-27"),
("su su","susumyaing1989@gmail.com","2017-01-27");
UPDATE tbl_subscribe SET name="su su", email="susumyaing1989@gmail.com", createdate="2017-01-27", WHERE id='4';
UPDATE tbl_subscribe SET name="su su", email="susumyaing1989@gmail.com", createdate="2017-01-27", WHERE id='5';
UPDATE tbl_subscribe SET name="su su", email="susumyaing1989@gmail.com", createdate="2017-01-27", WHERE id='6';
UPDATE tbl_subscribe SET name="su su", email="susumyaing1989@gmail.com", createdate="2017-01-27", WHERE id='7';
UPDATE tbl_subscribe SET name="su su", email="susumyaing1989@gmail.com", createdate="2017-01-27", WHERE id='8';



