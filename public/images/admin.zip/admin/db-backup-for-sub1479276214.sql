INSERT INTO tbl_subscribe(name, email, createdate) VALUES("su su","susu@gmail.com","2016-09-20"),
("aaaa","aa@ggg.ff","2016-09-24"),
("aa","aaa@aa.aa","2016-09-24");
UPDATE tbl_subscribe SET name="su su", email="susu@gmail.com", createdate="2016-09-20", WHERE id='1';
UPDATE tbl_subscribe SET name="aaaa", email="aa@ggg.ff", createdate="2016-09-24", WHERE id='2';
UPDATE tbl_subscribe SET name="aa", email="aaa@aa.aa", createdate="2016-09-24", WHERE id='3';



