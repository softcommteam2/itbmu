INSERT INTO students(StudentName, Country, Class, create_date) VALUES("khin hnin thaw","Myanmar","June","2016-11-15 11:54:53"),
("khin myat mon","Myanmar","June","2016-11-12 00:00:00");
UPDATE students SET StudentName="khin hnin thaw", Country="Myanmar", Class="June", create_date="2016-11-15 11:54:53" WHERE StudentID='1';
UPDATE students SET StudentName="khin myat mon", Country="Myanmar", Class="June", create_date="2016-11-12 00:00:00" WHERE StudentID='3';



