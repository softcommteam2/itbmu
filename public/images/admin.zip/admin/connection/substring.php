<?php
 function trim_text($text, $count){ 
      $trimed="";
      $text = str_replace("  ", " ", $text); 
      $string = explode(" ", $text); 
      for ($wordCounter = 0; $wordCounter <= $count;$wordCounter++ ){ 
      @$trimed .= $string[$wordCounter]; 
      if ( $wordCounter < $count ){ $trimed .= " "; } 
      else { $trimed .= "..."; } 
      } 
      $trimed = trim($trimed); 
      return $trimed; 
      } 
      // function trim_text1($text, $count){ 
      // $trimed="";
      // $text = str_replace("  ", " ", $text); 
      // $string = explode(" ", $text); 
      // for ($wordCounter = 0; $wordCounter <= $count;$wordCounter++ ){ 
      // @$trimed .= $string[$wordCounter]; 
      // if ( $wordCounter < $count ){ $trimed .= " "; } 
      // else { $trimed .= "..."; } 
      // } 
      // $trimed = trim($trimed); 
      // return $trimed; 
      // } 
?>