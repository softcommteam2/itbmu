<?php
// Create connection
$itbmu = new mysqli("localhost", "itbmuorg_user", "NH5fv5f4syznMZdCdX75Qz", "itbmuorg_db");

// Check connection
if ($itbmu->connect_error) {
    die("Connection Failed: " . $itbmu->connect_error);
}
//session_start();
  function queryString()
{
	$qString = array();
	
	foreach($_GET as $key => $value) {
		if (trim($value) != '') {
			$qString[] = $key. '=' . trim($value);
		} else {
			$qString[] = $key;
		}
	}
	
	$qString = implode('&', $qString);
	
	return $qString;
}

?>
