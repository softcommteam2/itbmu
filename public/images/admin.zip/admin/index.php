<?php
require_once('connection/connection.php');
require_once('function/config.php');
session_start();
// $uid=$_SESSION['uid']; //$username=$easy
// $userlevel=$_SESSION['userlevel']; //$userlevel=$ulevel
$uid = (!empty($_SESSION['uid']) ? $_SESSION['uid'] : "");
require_once($ui_page); 

?>

