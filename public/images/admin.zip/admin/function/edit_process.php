<?php
if(isset($_REQUEST['atupdate']) && $_GET['page'] == "activitytitle_update")
{
	$atitle =mysqli_real_escape_string($itbmu,$_POST['atitle']);
	
	$pgid=$_REQUEST['del'];
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("UPDATE tbl_activitytitle SET activitytitle= ? WHERE titleid= ?");
	$stmt->bind_param("si", $atitle, $pgid);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	
	$msg="Selected record is updated successfully!";
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=activitytitle_listtoupdate&Pg=a&msg=$msg\";</script>";
}

#photo_gallery
if(isset($_REQUEST['pgupdate']) && $_GET['page'] == "photogallery_update")
{
		$plabel =mysqli_real_escape_string($itbmu,$_POST['label1']);
		$pgid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE  tbl_photogallery SET titleid=?  WHERE id=?");
		$stmt->bind_param("si", $plabel, $pgid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------photo1----------------------------------#
		$nphoto = $_FILES['nphoto']['name'];
        $nphoto = str_replace(' ', '_', $nphoto);
		$target_dir = "/home5/itbmuorg/Data/Gallery/";
	  	$target_file = $target_dir . basename($nphoto);
	 	if ($nphoto == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo FROM tbl_photogallery WHERE id='$pgid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Gallery/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_photogallery SET photo= ? WHERE id= ?");
		$stmt->bind_param("si", $nphoto, $pgid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($nphoto);
	    move_uploaded_file($_FILES["nphoto"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	   	$msg="Selected record  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=photogallery_listtoupdate&msg=$msg\";</script>";

}

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#motto_update
if(isset($_REQUEST['mottosupdate']) && $_GET['page'] == "mottos_update")
{
		$ntitle =mysqli_real_escape_string($itbmu,$_POST['ntitle']);
		$nmottos =mysqli_real_escape_string($itbmu,$_POST['nmottos']);
		$nauthor =mysqli_real_escape_string($itbmu,$_POST['nauthor']);
		$mottosid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_mottos SET title=?,mottos=?,author=?  WHERE id=?");
		$stmt->bind_param("sssi", $ntitle, $nmottos,$nauthor,$mottosid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------photo1----------------------------------#
		$nphoto = $_FILES['nphoto']['name'];
        $nphoto = str_replace(' ', '_', $nphoto);
		$target_dir = "/home5/itbmuorg/Data/Mottos/";
	  	$target_file = $target_dir . basename($nphoto);
	 	if ($nphoto == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo FROM tbl_mottos WHERE id='$mottosid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Mottos/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_mottos SET photo= ? WHERE id= ?");
		$stmt->bind_param("si", $nphoto, $mottosid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($nphoto);
	    move_uploaded_file($_FILES["nphoto"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	  	$msg="Mottos  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=mottos_listtoupdate&msg=$msg\";</script>";

}
#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#org_update
if(isset($_REQUEST['orgupdate']) && $_GET['page'] == "org_update")
{
		$name =mysqli_real_escape_string($itbmu,$_POST['name']);
		$rank =mysqli_real_escape_string($itbmu,$_POST['rank']);
		$biography =mysqli_real_escape_string($itbmu,$_POST['biography']);
		$orgid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_organization SET name=?,biography=?, rank=?  WHERE id=?");
		$stmt->bind_param("sssi", $name, $biography,$rank,$orgid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------photo1----------------------------------#
		$photo = $_FILES['photo']['name'];
        $photo = str_replace(' ', '_', $photo);
		$target_dir = "/home5/itbmuorg/Data/Organization/";
	  	$target_file = $target_dir . basename($photo);
	 	if ($photo == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo FROM tbl_organization WHERE id='$orgid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Organization/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_organization SET photo= ? WHERE id= ?");
		$stmt->bind_param("si", $photo, $orgid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo);
	    move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	 	$msg="Organization  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=organization_listtoupdate&msg=$msg\";</script>";

}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#phd_update
if(isset($_REQUEST['phdupdate']) && $_GET['page'] == "phd_update"){

	$rollno =mysqli_real_escape_string($itbmu,$_POST['phdrollno']);
	$name=mysqli_real_escape_string($itbmu,$_POST['phdname']);
	$year =mysqli_real_escape_string($itbmu,$_POST['phdeyear']);
	$country =mysqli_real_escape_string($itbmu,$_POST['country']);
	$phd=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
	$stmt = $itbmu->stmt_init();
  	$stmt->prepare("UPDATE tbl_phd SET rollno=?,name=?,phdyear=?, country=? WHERE id=?");
  	$stmt->bind_param("ssssi", $rollno, $name, $year,$country, $phd);
  	$stmt->execute() or die($stmt->error);
  	$stmt->close();
  	$msg="Selected record is updated successfully!";
  	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_listtoupdate&Pg=a&msg=$msg\";</script>";
}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#gold_update
if(isset($_REQUEST['gupdate']) && $_GET['page'] == "gold_update"){

	$grollno =mysqli_real_escape_string($itbmu,$_POST['grollno']);
	$gname=mysqli_real_escape_string($itbmu,$_POST['gname']);
	$gyear =mysqli_real_escape_string($itbmu,$_POST['geyear']);
	$country=mysqli_real_escape_string($itbmu,$_POST['country']);
	$gold=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
	$stmt = $itbmu->stmt_init();
  	$stmt->prepare("UPDATE tbl_gold SET rollno=?,name=?,goldyear=?,country=? WHERE id=?");
  	$stmt->bind_param("ssssi", $grollno, $gname, $gyear,$country,$gold);
  	$stmt->execute() or die($stmt->error);
  	$stmt->close();
  	$msg="Selected record is updated successfully!";
  	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_listtoupdate&Pg=a&msg=$msg\";</script>";
}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#multimedia_update
if(isset($_REQUEST['multiupdate']) && $_GET['page'] == "multimedia_update")
{
		$title =mysqli_real_escape_string($itbmu,$_POST['multititle']);
		$presentername =mysqli_real_escape_string($itbmu,$_POST['multipresentername']);
    	$filetype =mysqli_real_escape_string($itbmu,$_POST['multifiletype']);
		$releasedate =mysqli_real_escape_string($itbmu,$_POST['releasedate']);
		$multimediaid=mysqli_real_escape_string($itbmu,$_POST['fff']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_multimedia SET title=?,presentername=?,filetype=?,releasedate=?  WHERE id=?");
		$stmt->bind_param("ssssi", $title, $presentername,$filetype,$releasedate,$multimediaid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

				$multiphoto = $_FILES['multiphoto']['name'];
                $multiphoto = str_replace(' ', '_', $multiphoto);
			$target_dir = "/home5/itbmuorg/Data/Multimedia/";
	  $target_file = $target_dir . basename($multiphoto);
	  //$uploadOk = 1;
	 //$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

	  if ($multiphoto == "") {
	    #code
	  }else{
	    	    //select old file
			$olde = $itbmu->query("SELECT file	FROM tbl_multimedia WHERE id='$multimediaid'")or die($itbmu->error);
			$drow = $olde->fetch_assoc();
	    $old = $drow['file'];

	    if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Multimedia/$old";
	      unlink($ofile_dir);//delete old file
	    }

			$stmt = $itbmu->stmt_init();
			$stmt->prepare("UPDATE tbl_multimedia SET file= ? WHERE id= ?");
			$stmt->bind_param("si", $multiphoto, $multimediaid);
			$stmt->execute() or die($stmt->error);
			$stmt->close();

	    $target_file = $target_dir . basename($multiphoto);
	    move_uploaded_file($_FILES["multiphoto"]["tmp_name"], $target_file);
	  }
	   
	  $msg="Multimedia  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=multimedia_listtoupdate&msg=$msg\";</script>";

}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#	
#magazine	
if(isset($_REQUEST['magupdate']) && $_GET['page'] == "magazine_update")
{
		$title =mysqli_real_escape_string($itbmu,$_POST['title']);
		$volumeno =mysqli_real_escape_string($itbmu,$_POST['volumeno']);
    	$mpublishedyear=mysqli_real_escape_string($itbmu,$_POST['mpublishedyear']);
		$epublishedyear =mysqli_real_escape_string($itbmu,$_POST['epublishedyear']);
		$content =mysqli_real_escape_string($itbmu,$_POST['content']);
		$magazineid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_magazine SET title=?,volumeno=?,mpublishedyear=?,epublishedyear=?,content=?  WHERE id=?");
		$stmt->bind_param("sssssi", $title, $volumeno,$mpublishedyear,$epublishedyear,$content,$magazineid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------cover_photo----------------------------------#
		$fcoverphoto = $_FILES['fcoverphoto']['name'];
        $fcoverphoto = str_replace(' ', '_', $fcoverphoto);
		$target_dir = "/home5/itbmuorg/Data/Magazine/";
	  	$target_file = $target_dir . basename($fcoverphoto);
	 	if ($fcoverphoto == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT coverphoto	 FROM tbl_magazine WHERE id='$magazineid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['coverphoto'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Magazine/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_magazine SET coverphoto	= ? WHERE id= ?");
		$stmt->bind_param("si", $fcoverphoto, $magazineid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($fcoverphoto);
	    move_uploaded_file($_FILES["fcoverphoto"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	  #-----------------------------------------Article----------------------------------------------#
	  	$article = $_FILES['article']['name'];
        $article = str_replace(' ', '_', $article);
		$target_dir = "/home5/itbmuorg/Data/Magazine/";
	  	$target_file = $target_dir . basename($article);
	 	if ($article == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldeies = $itbmu->query("SELECT article	 FROM tbl_magazine WHERE id='$magazineid'")or die($itbmu->error);
		$awn_kim = $oldeies->fetch_assoc();
	    $goldies = $awn_kim['article'];
		if ($goldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Magazine/$goldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_magazine SET article= ? WHERE id= ?");
		$stmt->bind_param("si", $article, $magazineid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($article);
	    move_uploaded_file($_FILES["article"]["tmp_name"], $target_file);
	  }
	#--------------------------------------------------------------------------------------------#
	    $msg="Magazine  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=magazine_listtoupdate&msg=$msg\";</script>";

}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#new_list
if(isset($_REQUEST['newsupdate']) && $_GET['page'] == "news_update")
{
		$engtitle =mysqli_real_escape_string($itbmu,$_POST['engtitle']);
		$engnews=mysqli_real_escape_string($itbmu,$_POST['engnews']);
		$date =mysqli_real_escape_string($itbmu,$_POST['upcomedate']);
		$newsid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET newstitleeng=?,newseng=?,upcomedate=?  WHERE id=?");
		$stmt->bind_param("sssi", $engtitle, $engnews,$date,$newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------photo1----------------------------------#
		$photo1 = $_FILES['photo1']['name'];
        $photo1 = str_replace(' ', '_', $photo1);
		$target_dir = "/home5/itbmuorg/Data/News/";
	  	$target_file = $target_dir . basename($photo1);
	 	if ($photo1 == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo1 FROM tbl_newsandevents WHERE id='$newsid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo1'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/News/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET photo1= ? WHERE id= ?");
		$stmt->bind_param("si", $photo1, $newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo1);
	    move_uploaded_file($_FILES["photo1"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	  #-----------------------------------------Photo2----------------------------------------------#
	  	$photo2 = $_FILES['photo2']['name'];
        $photo2 = str_replace(' ', '_', $photo2);
		$target_dir = "/home5/itbmuorg/Data/News/";
	  	$target_file = $target_dir . basename($photo2);
	 	if ($photo2 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldeies = $itbmu->query("SELECT photo2	FROM tbl_newsandevents WHERE id='$newsid'")or die($itbmu->error);
		$awn_kim = $oldeies->fetch_assoc();
	    $goldies = $awn_kim['photo2'];
		if ($goldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/News/$goldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET photo2= ? WHERE id= ?");
		$stmt->bind_param("si", $photo2, $newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo2);
	    move_uploaded_file($_FILES["photo2"]["tmp_name"], $target_file);
	  }
	#--------------------------------------------------------------------------------------------#
	#-------------------------------------photo3----------------------------------------------#
		$photo3 = $_FILES['photo3']['name'];
        $photo3 = str_replace(' ', '_', $photo3);
		$target_dir = "/home5/itbmuorg/Data/News/";
	  	$target_file = $target_dir . basename($photo3);
	 	if ($photo3 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldy = $itbmu->query("SELECT photo3	FROM tbl_newsandevents WHERE id='$newsid'")or die($itbmu->error);
		$billy = $oldy->fetch_assoc();
	    $holdies = $billy['photo3'];
		if ($holdies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/News/$holdies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET photo3= ? WHERE id= ?");
		$stmt->bind_param("si", $photo3, $newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo3);
	    move_uploaded_file($_FILES["photo3"]["tmp_name"], $target_file);
	  }	
	#----------------------------------------------------------------------------------------------------------#
	#---------------------------------------------Photo4---------------------------------------------------#
	
		$photo4 = $_FILES['photo4']['name'];
        $photo4 = str_replace(' ', '_', $photo4);
		$target_dir = "/home5/itbmuorg/Data/News/";
	  	$target_file = $target_dir . basename($photo4);
	 	if ($photo4 == "") {
	    #code
	  	}else{
	    	    //select old file
		$older = $itbmu->query("SELECT photo4	FROM tbl_newsandevents WHERE id='$newsid'")or die($itbmu->error);
		$dani_daniels = $older->fetch_assoc();
	    $joldies = $dani_daniels['photo4'];
		if ($joldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/News/$joldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET photo4= ? WHERE id= ?");
		$stmt->bind_param("si", $photo4, $newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo4);
	    move_uploaded_file($_FILES["photo4"]["tmp_name"], $target_file);
	  }	
	#--------------------------------------------------------------------------------------------------------------#
	#--------------------------------------------photo5---------------------------------------------------------#
		$photo5 = $_FILES['photo5']['name'];
        $photo5 = str_replace(' ', '_', $photo5);
		$target_dir = "/home5/itbmuorg/Data/News/";
	  	$target_file = $target_dir . basename($photo5);
	 	if ($photo5 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldest = $itbmu->query("SELECT photo5	 FROM tbl_newsandevents WHERE id='$newsid'")or die($itbmu->error);
		$maria_ozawa = $oldest->fetch_assoc();
	    $koldies = $maria_ozawa['photo5'];
		if ($koldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/News/$koldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_newsandevents SET photo5= ? WHERE id= ?");
		$stmt->bind_param("si", $photo5, $newsid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($photo5);
	    move_uploaded_file($_FILES["photo5"]["tmp_name"], $target_file);
	  }	  
	#--------------------------------------------------------------------------------------------------------------------#
		
	    $msg="Selected record  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=news_listtoupdate&msg=$msg\";</script>";

}
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#faculty_update
if(isset($_REQUEST['faupdate']) && $_GET['page'] == "faculties_update")
{
		$facuname =mysqli_real_escape_string($itbmu,$_POST['facultyname']);
		$department =mysqli_real_escape_string($itbmu,$_POST['department']);
    	$description =mysqli_real_escape_string($itbmu,$_POST['description']);
		$faculityid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET faculty=?,department=?,description=?  WHERE id=?");
		$stmt->bind_param("sssi", $facuname, $department,$description,$faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------photo1----------------------------------#
		$faphoto = $_FILES['faphoto']['name'];
        $faphoto = str_replace(' ', '_', $faphoto);
		$target_dir = "/home5/itbmuorg/Data/faculties/";
	  	$target_file = $target_dir . basename($faphoto);
	 	if ($faphoto == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo1 FROM tbl_faculties WHERE id='$faculityid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo1'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/faculties/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET photo1= ? WHERE id= ?");
		$stmt->bind_param("si", $faphoto, $faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($faphoto);
	    move_uploaded_file($_FILES["faphoto"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	  #-----------------------------------------Photo2----------------------------------------------#
	  	$faphoto2 = $_FILES['faphoto2']['name'];
        $faphoto2 = str_replace(' ', '_', $faphoto2);
		$target_dir = "/home5/itbmuorg/Data/faculties/";
	  	$target_file = $target_dir . basename($faphoto2);
	 	if ($faphoto2 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldeies = $itbmu->query("SELECT photo2	FROM tbl_faculties WHERE id='$faculityid'")or die($itbmu->error);
		$awn_kim = $oldeies->fetch_assoc();
	    $goldies = $awn_kim['photo2'];
		if ($goldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/faculties/$goldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET photo2= ? WHERE id= ?");
		$stmt->bind_param("si", $faphoto2, $faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($faphoto2);
	    move_uploaded_file($_FILES["faphoto2"]["tmp_name"], $target_file);
	  }
	#--------------------------------------------------------------------------------------------#
	#-------------------------------------photo3----------------------------------------------#
		$faphoto3 = $_FILES['faphoto3']['name'];
        $faphoto3 = str_replace(' ', '_', $faphoto3);
		$target_dir = "/home5/itbmuorg/Data/faculties/";
	  	$target_file = $target_dir . basename($faphoto3);
	 	if ($faphoto3 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldy = $itbmu->query("SELECT photo3	FROM tbl_faculties WHERE id='$faculityid'")or die($itbmu->error);
		$billy = $oldy->fetch_assoc();
	    $holdies = $billy['photo3'];
		if ($holdies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/faculties/$holdies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET photo3= ? WHERE id= ?");
		$stmt->bind_param("si", $faphoto3, $faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($faphoto3);
	    move_uploaded_file($_FILES["faphoto3"]["tmp_name"], $target_file);
	  }	
	#----------------------------------------------------------------------------------------------------------#
	#---------------------------------------------Photo4---------------------------------------------------#
	
		$faphoto4 = $_FILES['faphoto4']['name'];
        $faphoto4 = str_replace(' ', '_', $faphoto4);
		$target_dir = "/home5/itbmuorg/Data/faculties/";
	  	$target_file = $target_dir . basename($faphoto4);
	 	if ($faphoto4 == "") {
	    #code
	  	}else{
	    	    //select old file
		$older = $itbmu->query("SELECT photo4	FROM tbl_faculties WHERE id='$faculityid'")or die($itbmu->error);
		$dani_daniels = $older->fetch_assoc();
	    $joldies = $dani_daniels['photo4'];
		if ($joldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/faculties/$joldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET photo4= ? WHERE id= ?");
		$stmt->bind_param("si", $faphoto4, $faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($faphoto4);
	    move_uploaded_file($_FILES["faphoto4"]["tmp_name"], $target_file);
	  }	
	#--------------------------------------------------------------------------------------------------------------#
	#--------------------------------------------photo5---------------------------------------------------------#
		$faphoto5 = $_FILES['faphoto5']['name'];
        $faphoto5 = str_replace(' ', '_', $faphoto5);
		$target_dir = "/home5/itbmuorg/Data/faculties/";
	  	$target_file = $target_dir . basename($faphoto5);
	 	if ($faphoto5 == "") {
	    #code
	  	}else{
	    	    //select old file
		$oldest = $itbmu->query("SELECT photo5	 FROM tbl_faculties WHERE id='$faculityid'")or die($itbmu->error);
		$maria_ozawa = $oldest->fetch_assoc();
	    $koldies = $maria_ozawa['photo5'];
		if ($koldies != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/faculties/$koldies";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_faculties SET photo5= ? WHERE id= ?");
		$stmt->bind_param("si", $faphoto5, $faculityid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($faphoto5);
	    move_uploaded_file($_FILES["faphoto5"]["tmp_name"], $target_file);
	  }	  
	#--------------------------------------------------------------------------------------------------------------------#
		
	    $msg="Faculties  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=faculties_listtoupdate&msg=$msg\";</script>";

}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


/*if(isset($_REQUEST['phdupdate']) && $_GET['page'] == "phd_update")
{
	$rollno =mysqli_real_escape_string($itbmu,$_POST['phdrollno']);
	$name=mysqli_real_escape_string($itbmu,$_POST['phdname']);
	$year =mysqli_real_escape_string($itbmu,$_POST['phdeyear']);
	$phd=$_REQUEST['del'];
    $query ="UPDATE  tbl_phd SET rollno='$rollno',name='$name',phdyear='$year' WHERE id='$phd'";
	 $req = $itbmu->query($query)or die($itbmus->error);
		$msg="Phd is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_listtoupdate&Pg=a&msg=$msg\";</script>";
	}*/
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#member
if(isset($_REQUEST['memberupdate']) && $_GET['page'] == "member_update")
{
		$membername =mysqli_real_escape_string($itbmu,$_POST['membername']);
		$class=mysqli_real_escape_string($itbmu,$_POST['class']);
		$country=mysqli_real_escape_string($itbmu,$_POST['country']);
		$gender=mysqli_real_escape_string($itbmu,$_POST['gender']);
		$membernrc =mysqli_real_escape_string($itbmu,$_POST['membernrc']);
		$dob =mysqli_real_escape_string($itbmu,$_POST['dob']);
		$pob =mysqli_real_escape_string($itbmu,$_POST['pob']);
		$fathername =mysqli_real_escape_string($itbmu,$_POST['fathername']);
		$citizenship =mysqli_real_escape_string($itbmu,$_POST['citizenship']);
		$maritalstatus =mysqli_real_escape_string($itbmu,$_POST['maritalstatus']);
		$religion =mysqli_real_escape_string($itbmu,$_POST['religion']);
		$pha=mysqli_real_escape_string($itbmu,$_POST['pha']);
		$fax =mysqli_real_escape_string($itbmu,$_POST['fax']);
		$postaladdress =mysqli_real_escape_string($itbmu,$_POST['postaladdress']);
		$aqy =mysqli_real_escape_string($itbmu,$_POST['aqy']);
		$language =mysqli_real_escape_string($itbmu,$_POST['language']);
		$presentemployment =mysqli_real_escape_string($itbmu,$_POST['presentemployment']);
		$diploma =mysqli_real_escape_string($itbmu,$_POST['diploma']);
		$status =mysqli_real_escape_string($itbmu,$_POST['status']);
		$memberid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		#--------------------------------tbl_member----------------------#
		$stmt->prepare("UPDATE tbl_itbmumember SET name=?,gender=?,nrc=?,dob=?,pob=?,fathername=?,citizenship=?,maritalstatus=?, religion=?,pha=?,fax=?,postaladdress=?,aqy=?,language=?,presentemployment=?,diploma=?,status=?  WHERE id=?");
		$stmt->bind_param("sssssssssssssssssi", $membername, $gender,$membernrc,$dob,$pob,$fathername,$citizenship,$maritalstatus,$religion,$pha,$fax,$postaladdress,$aqy,$language,$presentemployment,$diploma,$status,$memberid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------------------------------tbl_student--------------------#
		/*$stmt->prepare("UPDATE students SET StudentName=?,Country=?,Class=?  WHERE  	StudentID=?");
		$stmt->bind_param("sssi", $membername, $country,$class,$memberid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();*/
		
		#-------------photo1----------------------------------#
		$fphoto = $_FILES['fphoto']['name'];
        $fphoto = str_replace(' ', '_', $fphoto);
		$target_dir = "/home5/itbmuorg/Data/Member/";
	  	$target_file = $target_dir . basename($fphoto);
	 	if ($fphoto == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT photo FROM tbl_itbmumember WHERE id='$memberid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['photo'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Member/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_itbmumember SET photo= ? WHERE id= ?");
		$stmt->bind_param("si", $fphoto, $memberid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($fphoto);
	    move_uploaded_file($_FILES["fphoto"]["tmp_name"], $target_file);
	  }
	  #-----------------------------------------------------------------------------------------------#
	  	$msg="Member  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=member_listtoupdate&msg=$msg\";</script>";

}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#course_timetable
if(isset($_REQUEST['courseupdate']) && $_GET['page'] == "coursetimetable_update")
{
		$coursename =mysqli_real_escape_string($itbmu,$_POST['coursename']);
		$opendate=mysqli_real_escape_string($itbmu,$_POST['opendate']);
		$opentime =mysqli_real_escape_string($itbmu,$_POST['opentime']);
		$openday =mysqli_real_escape_string($itbmu,$_POST['openday']);
		$courseid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE  tbl_coursetimetable SET coursename=?,opendate=?,opentime=?,openday=?  WHERE id=?");
		$stmt->bind_param("ssssi", $coursename, $opendate,$opentime,$openday,$courseid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		$msg="Course timetable is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=coursetimetable_listtoupdate&msg=$msg\";</script>";
	}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
if(isset($_REQUEST['examupdate']) && $_GET['page'] == "examresult_update")
{
	$examtype=mysqli_real_escape_string($itbmu,$_POST['examtype']);
		$coursename=mysqli_real_escape_string($itbmu,$_POST['coursename']);
		$courseyear=mysqli_real_escape_string($itbmu,$_POST['courseyear']);
		$resultdate =mysqli_real_escape_string($itbmu,$_POST['resultdate']);
		$examid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		#--------------------------------tbl_member----------------------#
		$stmt->prepare("UPDATE tbl_examresult SET examtype=?, coursename=?,courseyear=?,resultdate=? WHERE id=?");
		$stmt->bind_param("ssssi",$examtype,$coursename,$courseyear,$resultdate,$examid );
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		#-------------------------------------tbl_student--------------------#
		/*$stmt->prepare("UPDATE students SET StudentName=?,Country=?,Class=?  WHERE  	StudentID=?");
		$stmt->bind_param("sssi", $membername, $country,$class,$memberid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();*/
		
		#-------------photo1----------------------------------#
		$fresultfile = $_FILES['fresultfile']['name'];
        $fresultfile = str_replace(' ', '_', $fresultfile);
		$target_dir = "/home5/itbmuorg/Data/Exam/";
	  	$target_file = $target_dir . basename($fresultfile);
	 	if ($fresultfile == "") {
	    #code
	  	}else{
	    	    //select old file
		$olde = $itbmu->query("SELECT resultfile FROM tbl_examresult WHERE id='$examid'")or die($itbmu->error);
		$drow = $olde->fetch_assoc();
	    $old = $drow['resultfile'];
		if ($old != "") {
	      $ofile_dir = "/home5/itbmuorg/Data/Exam/$old";
	      unlink($ofile_dir);//delete old file
	    }
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE tbl_examresult SET resultfile= ? WHERE id= ?");
		$stmt->bind_param("si", $fresultfile, $examid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();

	    $target_file = $target_dir . basename($fresultfile);
	    move_uploaded_file($_FILES["fresultfile"]["tmp_name"], $target_file);
	  }
	$msg="Selected record is updated successfully!";
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=examresult_listtoupdate&Pg=a&msg=$msg\";</script>";
}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#lecture_update
if(isset($_REQUEST['lecupdate']) && $_GET['page'] == "lecture_update")
{
		$name=mysqli_real_escape_string($itbmu,$_POST['lecname']);
		$email =mysqli_real_escape_string($itbmu,$_POST['lecemail']);
		$address =mysqli_real_escape_string($itbmu,$_POST['lecaddress']);
		$phone =mysqli_real_escape_string($itbmu,$_POST['lecphone']);
		$lecid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE  tbl_lecture SET  lecturename=?,lecemail=?,address=?,phone=? WHERE lecid=?");
		$stmt->bind_param("ssssi", $name, $email,$address,$phone,$lecid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		$msg="Lecture is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=lecture_listtoupdate&Pg=a&msg=$msg\";</script>";
	}
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#Subject_update
if(isset($_REQUEST['subjupdate']) && $_GET['page'] == "subject_update")
{
		$subjno =mysqli_real_escape_string($itbmu,$_POST['subjno']);
		$subjname=mysqli_real_escape_string($itbmu,$_POST['subname']);
		$lectureby =mysqli_real_escape_string($itbmu,$_POST['lectureby']);
		$semester =mysqli_real_escape_string($itbmu,$_POST['semester']);
		$coursename=mysqli_real_escape_string($itbmu,$_POST['coursename']);
		$subjid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE  tbl_course SET courseno=?,subject=?,lecid=?,semester=?,id=?
 WHERE courseid=?");
		$stmt->bind_param("sssssi", $subjno, $subjname,$lectureby,$semester,$coursename,$subjid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
		$msg="Course  is updated successfully!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=subject_listtoupdate&Pg=a&msg=$msg\";</script>";
	}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#course_detail
if(isset($_REQUEST['ccupdate']) && $_GET['page'] == "coursedetail_update")
{
		$courseyear =mysqli_real_escape_string($itbmu,$_POST['year']);
		$coursename=mysqli_real_escape_string($itbmu,$_POST['coursename']);
		$semester =mysqli_real_escape_string($itbmu,$_POST['semester']);
		$subject =mysqli_real_escape_string($itbmu,$_POST['subject']);
		$time=mysqli_real_escape_string($itbmu,$_POST['time']);
		$day =mysqli_real_escape_string($itbmu,$_POST['day']);
		$hall =mysqli_real_escape_string($itbmu,$_POST['hall']);
		$coursedetailid=mysqli_real_escape_string($itbmu,$_REQUEST['del']);
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("UPDATE  tbl_coursetimetabledetail SET id=?,courseyear=?,semester=?,courseno=?,cdtday=?,cdttime=?,
	lecturehall=? WHERE coursetimetableid=?");
		$stmt->bind_param("sssssssi", $coursename, $courseyear,$semester,$subject,$day,$time,$hall,$coursedetailid);
		$stmt->execute() or die($stmt->error);
		$stmt->close();
	$msg="Course detail is updated successfully!";
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=coursedetail_listtoupdate&msg=$msg\";</script>";
	}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
?>
