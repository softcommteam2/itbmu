<?php
function File_Upload_Attack(array $file, $ext = array('jpg','png','pdf','docx')){
    # filter extension
   $Extension = substr($file['name'], strrpos($file['name'], '.') + 1);
    
    $result = false;
    
    foreach($ext as $value){
        if($Extension == $value){
            $result = true;
            break;
        }
    }
    
    
    return $result;
}

?>