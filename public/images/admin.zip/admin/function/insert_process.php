<?php
// activitytitle_entry.php
include('file_upload_attack.php');
include('xss_clean.php');

if(isset($_REQUEST['save']) && $_GET['page'] == "activitytitle_entry"){

	$title=xss_clean(mysqli_real_escape_string($itbmu,$_POST['title']));
	
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_activitytitle(activitytitle,createddate) VALUES (?,NOW())");
	$stmt->bind_param("s", $title);
	$stmt->execute() or die($stmt->error);
	$stmt->close();

	echo '<script language="javascript">';
	echo 'alert("Activity Title is Inserted Successfully")';
	echo '</script>';
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=activitytitle_entry\</script>";
}

// phd_entry.php
if(isset($_REQUEST['save']) && $_GET['page'] == "phd_entry")
{
	$srno= xss_clean(mysqli_real_escape_string($itbmu,$_POST['srno']));
	$rollno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['rollno']));
	$name=xss_clean(mysqli_real_escape_string($itbmu,$_POST['name']));
	$eyear=xss_clean(mysqli_real_escape_string($itbmu,$_POST['eyear']));
	$country=xss_clean(mysqli_real_escape_string($itbmu,$_POST['country']));

	
	 if($rollno == ""){
		$msg2 ="Please Insert Roll No";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry&msg1=$msg2\";</script>";
	}
	else if($name == ""){
		$msg3 ="Please Insert Name";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry&msg2=$msg3\";</script>";
	}
	else if($eyear == ""){
		$msg4 ="Please Insert Year";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry&msg3=$msg4\";</script>";
	}
	else if($country == ""){
		$msg5 ="Please Insert Country";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry&msg4=$msg5\";</script>";
	}
	else{
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT * FROM tbl_phd WHERE name=?");
		$stmt->bind_param("s", $name);
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		$num = $stmt->num_rows();
		$stmt->close();
		if($num != '')
		{
			$msg_duplicate='This Name alerady exist';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry&msg_duplicate=$msg_duplicate\";</script>";
		}
		else
		{
			$stmt = $itbmu->stmt_init();
			$stmt->prepare("INSERT INTO tbl_phd(srno,rollno,name,phdyear,country,createdate) VALUES (?,?,?,?,?,NOW())");
			$stmt->bind_param("sssss", $srno, $rollno, $name,$eyear,$country);
			$stmt->execute() or die($stmt->error);
			$stmt->close();
			
		}
	}
			echo '<script language="javascript">';
			echo 'alert("Ph.D Holder is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=phd_entry\</script>";
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// gold_entry.php
if(isset($_REQUEST['save']) && $_GET['page'] == "gold_entry")
{
	$srno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['srno']));
	$rollno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['rollno']));
	$name=xss_clean(mysqli_real_escape_string($itbmu,$_POST['name']));
	$eyear=xss_clean(mysqli_real_escape_string($itbmu,$_POST['eyear']));
	$country=xss_clean(mysqli_real_escape_string($itbmu,$_POST['country']));

	
	 if($rollno == ""){
		$msg2 ="Please Insert Roll No";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry&msg1=$msg2\";</script>";
	}
	else if($name == ""){
		$msg3 ="Please Insert Name";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry&msg2=$msg3\";</script>";
	}
	else if($eyear == ""){
		$msg4 ="Please Insert Year";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry&msg3=$msg4\";</script>";
	}
	else if($country == ""){
		$msg5 ="Please Insert Country";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry&msg4=$msg5\";</script>";
	}
	else{
		$stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT * FROM tbl_gold WHERE name=?");
		$stmt->bind_param("s", $name);
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		$num = $stmt->num_rows();
		$stmt->close();
		if($num != '')
		{
			$msg_duplicate='This Name alerady exist';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry&msg_duplicate=$msg_duplicate\";</script>";
		}
		else
		{
			$stmt = $itbmu->stmt_init();
			$stmt->prepare("INSERT INTO tbl_gold(srno,rollno,name,goldyear,country,createdate) VALUES (?,?,?,?,?,NOW())");
			$stmt->bind_param("sssss", $srno, $rollno, $name,$eyear,$country);
			$stmt->execute() or die($stmt->error);
			$stmt->close();
			
		}
	}
			echo '<script language="javascript">';
			echo 'alert("Gold Medalists is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=gold_entry\</script>";
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// multimedia_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "multimedia_entry"){

	$title=xss_clean(mysqli_real_escape_string($itbmu,$_POST['title']));

	$stmt = $itbmu->stmt_init();
	$stmt->prepare("SELECT id FROM tbl_multimedia WHERE title=?");
	$stmt->bind_param("s", $title);
	$stmt->execute() or die($stmt->error);
	$stmt->store_result();
	$numrow = $stmt->num_rows();
	//$stmt->close();
	
	if(!File_Upload_Attack($_FILES['mediafile'], array('mp3','mp4'))){
			    echo '<script language="javascript">';
    			echo 'alert("We Only Allow Access mp3 and mp4 extension")';
    			echo '</script>';
    			echo "<script>window.location=\"index.php?page=multimedia_entry\"</script>";
                return false;
    }
    

	if($numrow == 1) {
		$duplicate = "This title already exist!";
		print "<script language=\"JavaScript\">window.location.href=\"index.php?page=multimedia_entry&msg_duplicate=$duplicate\";</script>";
	} else {

	$presentername=mysqli_real_escape_string($itbmu,$_POST['presentername']);
	$filetype=mysqli_real_escape_string($itbmu,$_POST['filetype']);
	$myDate=mysqli_real_escape_string($itbmu,$_POST['myDate']);


	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_multimedia(title,presentername,filetype,releasedate,createdate) VALUES (?,?,?,?,NOW())");
			$stmt->bind_param("ssss", $title,$presentername,$filetype,$myDate);
			$stmt->execute() or die($stmt->error);
			$stmt->close();
			$last_id = $itbmu->insert_id;

			//-----------------------//
			
			

			$pfile = $_FILES['mediafile']['name'];
			$pfile = str_replace(' ', '_', $pfile);

			$target_dir = "/home5/itbmuorg/Data/Multimedia/";
			$target_file = $target_dir . basename($pfile);
			//$upload1Ok = 1;
			//$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

			if ($pfile == "") {
				#code
			}else{
				//$pfile = substr($pfile, 0, -4) . '_' . date('Y-m-d-H-i-s') . '_' . uniqid() . '.pdf';

				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_multimedia SET file= ? WHERE id= ?");
				$stmt->bind_param("si", $pfile, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();

				$target_file = $target_dir . basename($pfile);
				move_uploaded_file($_FILES["mediafile"]["tmp_name"], $target_file);
				
				
			}

			//-------------------------//
			echo '<script language="javascript">';
			echo 'alert("Multimedia is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=multimedia_entry\</script>";
			
				
			}
		}

// magazine_entry.php
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
if(isset($_REQUEST['save']) && $_GET['page'] == "magazine_entry"){

	$title=xss_clean(mysqli_real_escape_string($itbmu,$_POST['title']));
	$volumeno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['volumeno']));
	$mpublishedyear=xss_clean(mysqli_real_escape_string($itbmu,$_POST['mpublishedyear']));
	$epublishedyear=xss_clean(mysqli_real_escape_string($itbmu,$_POST['epublishedyear']));

	$content = preg_replace("/\r\n|\r/", "<br />", $_POST["content"]);
	$content = trim($content);
    
    
    
    $pfile = $_FILES['coverphoto']['name'];
    $extension = substr($pfile, strrpos($pfile, '.') + 1);
    if (($extension != "jpg") || ($extension != "png") && ($_FILES["coverphoto"]["type"] != "image/jpeg")){
            echo '<script language="javascript">';
			echo 'alert("We Only Allow Access jpg and png extension")';
			echo '</script>';
			echo "<script>window.location=\"index.php?page=magazine_entry\"</script>";
        return fasle;
    }
    $artical_file = $_FILES['article']['name'];
    
    if(!File_Upload_Attack($_FILES['article'])){
        echo '<script language="javascript">';
			echo 'alert("We Only Allow Access jpg,png,pdf, and docx extension")';
			echo '</script>';
			echo "<script>window.location=\"index.php?page=magazine_entry\"</script>";
        return false;
    }
    
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_magazine(title,volumeno,mpublishedyear,epublishedyear,content,createdate) VALUES (?,?,?,?,?,NOW())");
			$stmt->bind_param("sssss", $title,$volumeno,$mpublishedyear,$epublishedyear,$content);
			$stmt->execute() or die($stmt->error);
			$stmt->close();
			$last_id = $itbmu->insert_id;

			//-----------------------//

			$pfile = $_FILES['coverphoto']['name'];
			$pfile = str_replace(' ', '_', $pfile);

			$target_dir = "/home5/itbmuorg/Data/Magazine/";
			$target_file = $target_dir . basename($pfile);
			//$upload1Ok = 1;
			//$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

			if ($pfile == "") {
				#code
			}else{
				//$pfile = substr($pfile, 0, -4) . '_' . date('Y-m-d-H-i-s') . '_' . uniqid() . '.pdf';

				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_magazine SET coverphoto= ? WHERE id= ?");
				$stmt->bind_param("si", $pfile, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();

				$target_file = $target_dir . basename($pfile);
				move_uploaded_file($_FILES["coverphoto"]["tmp_name"], $target_file);
				
				
			}

			//-------------------------//
			
			//--------------------------//
			$pfile2 = $_FILES['article']['name'];
			$pfile2 = str_replace(' ', '_', $pfile2);

			$target_dir = "/home5/itbmuorg/Data/Magazine/";
			$target_file = $target_dir . basename($pfile2);
			//$upload1Ok = 1;
			//$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

			if ($pfile2 == "") {
				#code
			}else{
				//$pfile = substr($pfile, 0, -4) . '_' . date('Y-m-d-H-i-s') . '_' . uniqid() . '.pdf';

				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_magazine SET article= ? WHERE id= ?");
				$stmt->bind_param("si", $pfile2, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();

				$target_file = $target_dir . basename($pfile2);
				move_uploaded_file($_FILES["article"]["tmp_name"], $target_file);
				
				
			}
			
			
			
			echo '<script language="javascript">';
			echo 'alert("Multimedia is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=magazine_entry\</script>";
			
				
			}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
// news_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "news_entry"){
	$engtitle=xss_clean(mysqli_real_escape_string($itbmu,$_POST['engtitle']));
	$engnews=xss_clean(mysqli_real_escape_string($itbmu,$_POST['engnews']));
	$upcomedate=xss_clean(mysqli_real_escape_string($itbmu,$_POST['myDate']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_newsandevents(newstitleeng,newseng,upcomedate,createdate) VALUES (?,?,?,NOW())");
	$stmt->bind_param("sss",$engtitle,$engnews,$upcomedate);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	
	if(!File_Upload_Attack($_FILES['photo1'],array('jpg','png','jpeg','JPG'))){
        echo '<script language="javascript">';
			echo 'alert("We Only Allow Access jpg and png  Extension")';
			echo '</script>';
			echo "<script>window.location=\"index.php?page=news_entry\"</script>";
        return false;
    }
	$photo1 = $_FILES['photo1']['name'];
	$photo1 = str_replace(' ', '_', $photo1);
	$target_dir = "/home5/itbmuorg/Data/News/";
	$target_file = $target_dir . basename($photo1);
	if ($photo1 == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_newsandevents SET photo1= ? WHERE id= ?");
				$stmt->bind_param("si", $photo1, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo1);
				move_uploaded_file($_FILES["photo1"]["tmp_name"], $target_file);
				}
			//-------------------------//
			//--------------------------//
			$photo2 = $_FILES['photo2']['name'];
			$photo2 = str_replace(' ', '_', $photo2);
			$target_dir = "/home5/itbmuorg/Data/News/";
			$target_file = $target_dir . basename($photo2);
			if ($photo2 == "") {
				#code
			}else{
			    
			    if(!File_Upload_Attack($_FILES['photo2'],array('jpg','png','jpeg','JPG'))){
                    echo '<script language="javascript">';
            			echo 'alert("We Only Allow Access jpg and png  Extension in photo 2")';
            			echo '</script>';
            			echo "<script>window.location=\"index.php?page=news_entry\"</script>";
                    return false;
                }
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_newsandevents SET photo2= ? WHERE id= ?");
				$stmt->bind_param("si", $photo2, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo2);
				move_uploaded_file($_FILES["photo2"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo3 = $_FILES['photo3']['name'];
			$photo3 = str_replace(' ', '_', $photo3);
			$target_dir = "/home5/itbmuorg/Data/News/";
			$target_file = $target_dir . basename($photo3);
			if ($photo3 == "") {
				#code
			}else{
			    # validate
			    if(!File_Upload_Attack($_FILES['photo3'],array('jpg','png','jpeg','JPG'))){
                    echo '<script language="javascript">';
            			echo 'alert("We Only Allow Access jpg and png  Extension in photo 3")';
            			echo '</script>';
            			echo "<script>window.location=\"index.php?page=news_entry\"</script>";
                    return false;
                }
			    
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_newsandevents SET photo3= ? WHERE id= ?");
				$stmt->bind_param("si", $photo3, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo3);
				move_uploaded_file($_FILES["photo3"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo4 = $_FILES['photo4']['name'];
			$photo4 = str_replace(' ', '_', $photo4);
			$target_dir = "/home5/itbmuorg/Data/News/";
			$target_file = $target_dir . basename($photo4);
			
			if ($photo4 == "") {
				#code
				
				
			}else{
			    # validate
			    if(!File_Upload_Attack($_FILES['photo4'],array('jpg','png','jpeg','JPG'))){
                    echo '<script language="javascript">';
            			echo 'alert("We Only Allow Access jpg and png  Extension in photo 4")';
            			echo '</script>';
            			echo "<script>window.location=\"index.php?page=news_entry\"</script>";
                    return false;
                }
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_newsandevents SET photo4= ? WHERE id= ?");
				$stmt->bind_param("si", $photo4, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo4);
				move_uploaded_file($_FILES["photo4"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo5 = $_FILES['photo5']['name'];
			$photo5 = str_replace(' ', '_', $photo5);
			$target_dir = "/home5/itbmuorg/Data/News/";
			$target_file = $target_dir . basename($photo5);
			if ($photo5 == "") {
				# code
			}else{
			    # validate
			    if(!File_Upload_Attack($_FILES['photo5'],array('jpg','png','jpeg','JPG'))){
                    echo '<script language="javascript">';
            			echo 'alert("We Only Allow Access jpg and png  Extension in photo 5")';
            			echo '</script>';
            			echo "<script>window.location=\"index.php?page=news_entry\"</script>";
                    return false;
                }
                
                
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_newsandevents SET photo5= ? WHERE id= ?");
				$stmt->bind_param("si", $photo5, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo5);
				move_uploaded_file($_FILES["photo5"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			echo '<script language="javascript">';
			echo 'alert("News and Events is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=news_entry\</script>";
			}
			
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

// faculties_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "faculties_entry"){

	$facultyname=xss_clean(mysqli_real_escape_string($itbmu,$_POST['facultyname']));
	$department=xss_clean(mysqli_real_escape_string($itbmu,$_POST['department']));
	$description=xss_clean(mysqli_real_escape_string($itbmu,$_POST['description']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_faculties(faculty,department,description,createdate) VALUES (?,?,?,NOW())");
	$stmt->bind_param("sss",$facultyname,$department,$description);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$photo1 = $_FILES['photo1']['name'];
	
	if(!File_Upload_Attack($_FILES['photo1'],array('jpg','png','jpeg'))){
		echo '<script>alert("We Only Allow Access jpg and png  Extension in photo 1")</script>';
		echo "<script>window.location=\"index.php?page=faculties_entry\"</script>";
        return false;
    }
	$photo1 = str_replace(' ', '_', $photo1);
	$target_dir = "/home5/itbmuorg/Data/faculties/";
	$target_file = $target_dir . basename($photo1);
	if ($photo1 == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_faculties SET photo1= ? WHERE id= ?");
				$stmt->bind_param("si", $photo1, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo1);
				move_uploaded_file($_FILES["photo1"]["tmp_name"], $target_file);
				}
			//-------------------------//
			//--------------------------//
			$photo2 = $_FILES['photo2']['name'];
			$photo2 = str_replace(' ', '_', $photo2);
			$target_dir = "/home5/itbmuorg/Data/faculties/";
			$target_file = $target_dir . basename($photo2);
			if ($photo2 == "") {
				#code
			}else{
			    # validate
			    if(!File_Upload_Attack($_FILES['photo2'],array('jpg','png','jpeg'))){
            		echo '<script>alert("We Only Allow Access jpg and png  Extension in photo 2")</script>';
            		echo "<script>window.location=\"index.php?page=faculties_entry\"</script>";
                    return false;
                }
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_faculties SET photo2= ? WHERE id= ?");
				$stmt->bind_param("si", $photo2, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo2);
				move_uploaded_file($_FILES["photo2"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo3 = $_FILES['photo3']['name'];
			$photo3 = str_replace(' ', '_', $photo3);
			$target_dir = "/home5/itbmuorg/Data/faculties/";
			$target_file = $target_dir . basename($photo3);
			if ($photo3 == "") {
				#code
			}else{
			    if(!File_Upload_Attack($_FILES['photo3'],array('jpg','png','jpeg'))){
            		echo '<script>alert("We Only Allow Access jpg and png  Extension in photo 3")</script>';
            		echo "<script>window.location=\"index.php?page=faculties_entry\"</script>";
                    return false;
                }
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_faculties SET photo3= ? WHERE id= ?");
				$stmt->bind_param("si", $photo3, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo3);
				move_uploaded_file($_FILES["photo3"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo4 = $_FILES['photo4']['name'];
			$photo4 = str_replace(' ', '_', $photo4);
			$target_dir = "/home5/itbmuorg/Data/faculties/";
			$target_file = $target_dir . basename($photo4);
			if ($photo4 == "") {
				#code
			}else{
			    if(!File_Upload_Attack($_FILES['photo4'],array('jpg','png','jpeg'))){
            		echo '<script>alert("We Only Allow Access jpg and png  Extension in photo 4")</script>';
            		echo "<script>window.location=\"index.php?page=faculties_entry\"</script>";
                    return false;
                }
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_faculties SET photo4= ? WHERE id= ?");
				$stmt->bind_param("si", $photo4, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo4);
				move_uploaded_file($_FILES["photo4"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			$photo5 = $_FILES['photo5']['name'];
			$photo5 = str_replace(' ', '_', $photo5);
			$target_dir = "/home5/itbmuorg/Data/faculties/";
			$target_file = $target_dir . basename($photo5);
			if ($photo5 == "") {
				#code
			}else{
			    if(!File_Upload_Attack($_FILES['photo5'],array('jpg','png','jpeg'))){
            		echo '<script>alert("We Only Allow Access jpg and png  Extension in photo 5")</script>';
            		echo "<script>window.location=\"index.php?page=faculties_entry\"</script>";
                    return false;
                }
			    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_faculties SET photo5= ? WHERE id= ?");
				$stmt->bind_param("si", $photo5, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo5);
				move_uploaded_file($_FILES["photo5"]["tmp_name"], $target_file);
				}
			#------------------------------------------------------------------------#
			echo '<script language="javascript">';
			echo 'alert("Faculty is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=faculties_entry\</script>";
			}
			
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

// mottos_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "mottos_entry"){
	
	$title=xss_clean(mysqli_real_escape_string($itbmu,$_POST['title']));
	$mottos=xss_clean(mysqli_real_escape_string($itbmu,$_POST['mottos']));
	$author=xss_clean(mysqli_real_escape_string($itbmu,$_POST['author']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO  tbl_mottos(title,mottos,author,createdate) VALUES (?,?,?,NOW())");
	$stmt->bind_param("sss",$title,$mottos,$author);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$photo = $_FILES['photo']['name'];
	
	$photo = str_replace(' ', '_', $photo);
	$target_dir = "/home5/itbmuorg/Data/Mottos/";
	$target_file = $target_dir . basename($photo);
	if ($photo == "") {
				#code
			}else{
			    if(!File_Upload_Attack($_FILES['photo1'],array('jpg','png','jpeg'))){
            		echo '<script>alert("We Only Allow Access jpg and png  Extension!")</script>';
            		echo "<script>window.location=\"index.php?page=mottos_entry\"</script>";
                    return false;
                }
    
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_mottos SET photo= ? WHERE id= ?");
				$stmt->bind_param("si", $photo, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo);
				move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
				}
			//-------------------------//
			echo '<script language="javascript">';
			echo 'alert("Mottos is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=mottos_entry\</script>";
			}
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

// organization_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "organization_entry"){
	
	$name=xss_clean(mysqli_real_escape_string($itbmu,$_POST['name']));
	$rank=xss_clean(mysqli_real_escape_string($itbmu,$_POST['rank']));
	$biography=xss_clean(mysqli_real_escape_string($itbmu,$_POST['biography']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO  tbl_organization(name,biography,rank,createdate) VALUES (?,?,?,NOW())");
	$stmt->bind_param("sss",$name,$biography,$rank);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$photo = $_FILES['photo']['name'];
	$photo = str_replace(' ', '_', $photo);
	$target_dir = "/home5/itbmuorg/Data/Organization/";
	$target_file = $target_dir . basename($photo);
	if ($photo == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_organization SET photo= ? WHERE id= ?");
				$stmt->bind_param("si", $photo, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo);
				move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
				}
			//-------------------------//
			
			echo '<script language="javascript">';
			echo 'alert("Organization is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=organization_entry\</script>";
			}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

// memeber_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "member_entry"){
	
	$name=xss_clean(mysqli_real_escape_string($itbmu,$_POST['name']));
	$class=xss_clean(mysqli_real_escape_string($itbmu,$_POST['class']));
	$country=xss_clean(mysqli_real_escape_string($itbmu,$_POST['country']));
	$gender=xss_clean(mysqli_real_escape_string($itbmu,$_POST['gender']));
	$nrc=xss_clean(mysqli_real_escape_string($itbmu,$_POST['nrc']));
	$dob=xss_clean(mysqli_real_escape_string($itbmu,$_POST['dob']));
	$pob=xss_clean(mysqli_real_escape_string($itbmu,$_POST['myDate']));
	$fathername=xss_clean(mysqli_real_escape_string($itbmu,$_POST['fathername']));
	$citizenship=xss_clean(mysqli_real_escape_string($itbmu,$_POST['citizenship']));
	$maritalstatus=xss_clean(mysqli_real_escape_string($itbmu,$_POST['maritalstatus']));
	$religion=xss_clean(mysqli_real_escape_string($itbmu,$_POST['religion']));
	$pha=xss_clean(mysqli_real_escape_string($itbmu,$_POST['pha']));
	$fax=xss_clean(mysqli_real_escape_string($itbmu,$_POST['fax']));
	$postaladdress=xss_clean(mysqli_real_escape_string($itbmu,$_POST['postaladdress']));
	$aqy=xss_clean(mysqli_real_escape_string($itbmu,$_POST['aqy']));
	$language=xss_clean(mysqli_real_escape_string($itbmu,$_POST['language']));
	$presentemployment=xss_clean(mysqli_real_escape_string($itbmu,$_POST['presentemployment']));
	$diploma=xss_clean(mysqli_real_escape_string($itbmu,$_POST['diploma']));
	$status=xss_clean(mysqli_real_escape_string($itbmu,$_POST['status']));
	
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO  tbl_itbmumember	(name,gender,nrc,passport,dob,pob,fathername,citizenship,maritalstatus,religion,pha,fax,postaladdress,aqy,language,presentemployment,diploma,status,registrationdate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");
	$stmt->bind_param("ssssssssssssssssss",$name,$gender,$nrc,$nrc,$dob,$pob,$fathername,$citizenship,$maritalstatus,$religion,$pha,$fax,$postaladdress,$aqy,$language,$presentemployment,$diploma,$status);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$photo = $_FILES['photo']['name'];
	$photo = str_replace(' ', '_', $photo);
	$target_dir = "/home5/itbmuorg/Data/Member/";
	$target_file = $target_dir . basename($photo);
	if ($photo == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_itbmumember	SET photo= ? WHERE id= ?");
				$stmt->bind_param("si", $photo, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo);
				move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
				}
			//-------------------------//
			echo '<script language="javascript">';
			echo 'alert("Member is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=member_entry\</script>";
			}
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

// coursetimetable_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "coursetimetable_entry"){
	$coursename=xss_clean(mysqli_real_escape_string($itbmu,$_POST['coursename']));
	$opendate=xss_clean(mysqli_real_escape_string($itbmu,$_POST['opendate']));
	$opentime=xss_clean(mysqli_real_escape_string($itbmu,$_POST['opentime']));
	$openday=xss_clean(mysqli_real_escape_string($itbmu,$_POST['openday']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_coursetimetable(coursename,opendate,opentime,openday,postdate) VALUES (?,?,?,?,NOW())");
	$stmt->bind_param("ssss",$coursename,$opendate,$opentime,$openday);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	
	echo '<script language="javascript">';
	echo 'alert("Course Timetable is Inserted Successfully")';
	echo '</script>';
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=coursetimetable_entry\</script>";
}
#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
// photogallery_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "photogallery_entry"){
	
	$label1=xss_clean(mysqli_real_escape_string($itbmu,$_POST['label1']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO  tbl_photogallery(titleid,createdate) VALUES (?,NOW())");
	$stmt->bind_param("s",$label1);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$photo1 = $_FILES['photo1']['name'];
	$photo1 = str_replace(' ', '_', $photo1);
	$target_dir = "/home5/itbmuorg/Data/Gallery/";
	$target_file = $target_dir . basename($photo1);
	if ($photo1 == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_photogallery 	SET photo= ? WHERE id= ?");
				$stmt->bind_param("si", $photo1, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($photo1);
				move_uploaded_file($_FILES["photo1"]["tmp_name"], $target_file);
				}
			//-------------------------//
			echo '<script language="javascript">';
			echo 'alert("Photogallery is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=photogallery_entry\</script>";
			}
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#		

// examresult_entry.php

if(isset($_REQUEST['save']) && $_GET['page'] == "examresult_entry"){
	
	$examtype=xss_clean(mysqli_real_escape_string($itbmu,$_POST['examtype']));
	$coursename=xss_clean(mysqli_real_escape_string($itbmu,$_POST['coursename']));
	$courseyear=xss_clean(mysqli_real_escape_string($itbmu,$_POST['courseyear']));
	$resultdate=xss_clean(mysqli_real_escape_string($itbmu,$_POST['resultdate']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO  tbl_examresult(examtype,coursename,courseyear,resultdate,createdate) VALUES (?,?,?,?,NOW())");
	$stmt->bind_param("ssss",$examtype,$coursename,$courseyear,$resultdate);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	$last_id = $itbmu->insert_id;
	//-----------------------//
	$resultfile = $_FILES['resultfile']['name'];
	$resultfile = str_replace(' ', '_', $resultfile);
	$target_dir = "/home5/itbmuorg/Data/Exam/";
	$target_file = $target_dir . basename($resultfile);
	if ($resultfile == "") {
				#code
			}else{
				$stmt = $itbmu->stmt_init();
				$stmt->prepare("UPDATE tbl_examresult 	SET resultfile= ? WHERE id= ?");
				$stmt->bind_param("si", $resultfile, $last_id);
				$stmt->execute() or die($stmt->error);
				$stmt->close();
				$target_file = $target_dir . basename($resultfile);
				move_uploaded_file($_FILES["resultfile"]["tmp_name"], $target_file);
				}
			//-------------------------//
			echo '<script language="javascript">';
			echo 'alert("Examresult is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=examresult_entry\</script>";
			}

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#lecture_entry

if(isset($_REQUEST['lecsave']) && $_GET['page'] == "lecture_entry"){
	$name=xss_clean(mysqli_real_escape_string($itbmu,$_POST['lecname']));
	$email=xss_clean(mysqli_real_escape_string($itbmu,$_POST['lecemail']));
	$address=xss_clean(mysqli_real_escape_string($itbmu,$_POST['lecaddress']));
	$phone=xss_clean(mysqli_real_escape_string($itbmu,$_POST['lecphone']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("SELECT * FROM tbl_lecture WHERE lecturename=?");
	$stmt->bind_param("s", $name);
	$stmt->execute() or die($stmt->error);
	$stmt->store_result();
	$num = $stmt->num_rows();
	$stmt->close();
	if($num != '')
		{
			$msg_duplicate='This Lecture Name alerady exist!!!';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=lecture_entry&msg_duplicate=$msg_duplicate\";</script>";
		}
		else
		{
			$stmt = $itbmu->stmt_init();
			$stmt->prepare("INSERT INTO tbl_lecture(lecturename,lecemail,address,phone,createdate) VALUES (?,?,?,?,NOW())");
			$stmt->bind_param("ssss", $name,$email,$address,$phone);
			$stmt->execute() or die($stmt->error);
			$stmt->close();
			
		}
	
			echo '<script language="javascript">';
			echo 'alert("Lecture is Inserted Successfully")';
			echo '</script>';
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=lecture_entry\</script>";
}

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#subject_entry

if(isset($_REQUEST['subsave']) && $_GET['page'] == "subject_entry"){
	$courseno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['courseno']));
	$subjectname=xss_clean(mysqli_real_escape_string($itbmu,$_POST['subjectname']));
	$lectureby=xss_clean(mysqli_real_escape_string($itbmu,$_POST['lectureby']));
	$semester=xss_clean(mysqli_real_escape_string($itbmu,$_POST['semester']));
	$coursename=xss_clean(mysqli_real_escape_string($itbmu,$_POST['coursename']));
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_course(courseno,subject,lecid,semester,id,coursedate) VALUES (?,?,?,?,?,NOW())");
	$stmt->bind_param("sssss",$courseno,$subjectname,$lectureby,$semester,$coursename);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	
	echo '<script language="javascript">';
	echo 'alert("Subject is Inserted Successfully")';
	echo '</script>';
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=subject_entry\</script>";
}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#course_detail_entry

if(isset($_REQUEST['ccsave']) && $_GET['page'] == "coursedetail_entry"){
	$coursename=xss_clean(mysqli_real_escape_string($itbmu,$_POST['coursename']));
	$year=xss_clean(mysqli_real_escape_string($itbmu,$_POST['courseyear']));
	$semester=xss_clean(mysqli_real_escape_string($itbmu,$_POST['semester']));
	$courseno=xss_clean(mysqli_real_escape_string($itbmu,$_POST['courseno']));
	$day=xss_clean(mysqli_real_escape_string($itbmu,$_POST['openday']));
    $time=xss_clean(mysqli_real_escape_string($itbmu,$_POST['opentime']));
	$hall=xss_clean(mysqli_real_escape_string($itbmu,$_POST['hall']));
	
	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_coursetimetabledetail(id,courseyear,semester,courseno,cdtday,
	cdttime,lecturehall,cdtdate) VALUES (?,?,?,?,?,?,?,NOW())");
	$stmt->bind_param("sssssss",$coursename,$year,$semester,$courseno,$day,$time,$hall);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	
	echo '<script language="javascript">';
	echo 'alert("Course detail is Inserted Successfully")';
	echo '</script>';
	print "<script language=\"JavaScript\">window.location.href=\"index.php?page=coursedetail_entry\</script>";
}

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

?>
