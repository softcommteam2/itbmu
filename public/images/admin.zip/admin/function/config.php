<?php

$ui = (isset($_GET['page']) && $_GET['page'] != '')? $_GET['page'] :'';
	switch ($ui)
	{
                case 'activitytitle_delete';
		$ui_page="pages/activitytitle_delete.php";
		break;
		
		case 'activitytitle_update';
		$ui_page="pages/activitytitle_update.php";
		break;

		case 'activitytitle_listtoupdate';
		$ui_page="pages/activitytitle_listtoupdate.php";
		break;
		
		case 'activitytitle_listtodelete';
		$ui_page="pages/activitytitle_listtodelete.php";
		break;
		
		case 'activitytitle_list';
		$ui_page="pages/activitytitle_list.php";
		break;
		
		case 'activitytitle_entry';
		$ui_page="pages/activitytitle_entry.php";
		break;

		// list
                
                case 'subscribe_list';
		$ui_page="pages/subscribe_list.php";
		break;

                case 'usermanual';
		$ui_page="pages/usermanual.php";
		break;

		case 'export_subscribemailfilelist';
		$ui_page="pages/export_subscribemailfilelist.php";
		break;

		case 'export_subscribemaillist';
		$ui_page="pages/export_subscribemaillist.php";
		break;

		case 'export_studentfilelist';
		$ui_page="pages/export_studentfilelist.php";
		break;

		case 'export_studentlist';
		$ui_page="pages/export_studentlist.php";
		break;

		case 'organization_entry';
		$ui_page="pages/organization_entry.php";
		break;

		case 'org_update';
		$ui_page="pages/org_update.php";
		break;

		case 'organization_delete';
		$ui_page="pages/organization_delete.php";
		break;

		case 'organization_listtoupdate';
		$ui_page="pages/organization_listtoupdate.php";
		break;

		case 'organization_listtodelete';
		$ui_page="pages/organization_listtodelete.php";
		break;

		case 'organization_list';
		$ui_page="pages/organization_list.php";
		break;

		case 'book_list';
		$ui_page="pages/book_list.php";
		break;

		case 'coursedetail_list';
		$ui_page="pages/course_detaillist.php";
		break;

		case 'subject_list';
		$ui_page="pages/subject_list.php";
		break;

		case 'lecture_list';
		$ui_page="pages/lecture_list.php";
		break;

		case 'examresult_list';
		$ui_page="pages/examresult_list.php";
		break;

		case 'photogallery_list';
		$ui_page="pages/photogallery_list.php";
		break;

		case 'coursetimetable_list';
		$ui_page="pages/coursetimetable_list.php";
		break;

		case 'member_list';
		$ui_page="pages/member_list.php";
		break;

		case 'mottos_list';
		$ui_page="pages/mottos_list.php";
		break;

		case 'mottos_listtodelete';
		$ui_page="pages/mottos_listtodelete.php";
		break;

		case 'mottos_delete';
		$ui_page="pages/mottos_delete.php";
		break;

		case 'phd_delete';
		$ui_page="pages/phd_delete.php";
		break;

		case 'faculties_list';
		$ui_page="pages/faculties_list.php";
		break;

		case 'news_list';
		$ui_page="pages/news_list.php";
		break;

		case 'magazine_list';
		$ui_page="pages/magazine_list.php";
		break;

		case 'multimedia_list';
		$ui_page="pages/multimedia_list.php";
		break;

		case 'gold_list';
		$ui_page="pages/gold_list.php";
		break;

		case 'phd_list';
		$ui_page="pages/phd_list.php";
		break;

		case 'user_list';
		$ui_page="pages/user_list.php";
		break;

		// listtodelete
		case 'coursedetail_listtodelete';
		$ui_page="pages/coursedetail_listtodelete.php";
		break;

		case 'coursedetail_delete';
		$ui_page="pages/coursedetail_delete.php";
		break;

		case 'subject_listtodelete';
		$ui_page="pages/subject_listtodelete.php";
		break;

		case 'subject_delete';
		$ui_page="pages/subject_delete.php";
		break;

		case 'lecture_listtodelete';
		$ui_page="pages/lecture_listtodelete.php";
		break;

		case 'lectute_delete';
		$ui_page="pages/lectute_delete.php";
		break;

		case 'examresult_listtodelete';
		$ui_page="pages/examresult_listtodelete.php";
		break;

		case 'examresult_delete';
		$ui_page="pages/examresult_delete.php";
		break;

		case 'photogallery_listtodelete';
		$ui_page="pages/photogallery_listtodelete.php";
		break;

		case 'photogallery_delete';
		$ui_page="pages/photogallery_delete.php";
		break;

		case 'coursetimetable_listtodelete';
		$ui_page="pages/coursetimetable_listtodelete.php";
		break;

		case 'coursetimetable_delete';
		$ui_page="pages/coursetimetable_delete.php";
		break;

		case 'member_listtodelete';
		$ui_page="pages/member_listtodelete.php";
		break;

		case 'member_delete';
		$ui_page="pages/member_delete.php";
		break;

		case 'mottos_listtodelete';
		$ui_page="pages/mottos_listtodelete.php";
		break;

		case 'faculties_listtodelete';
		$ui_page="pages/faculties_listtodelete.php";
		break;

		case 'faculties_delete';
		$ui_page="pages/faculties_delete.php";
		break;

		case 'news_listtodelete';
		$ui_page="pages/news_listtodelete.php";
		break;

		case 'news_delete';
		$ui_page="pages/news_delete.php";
		break;

		case 'magazine_listtodelete';
		$ui_page="pages/magazine_listtodelete.php";
		break;

		case 'magazine_delete';
		$ui_page="pages/magazine_delete.php";
		break;

		case 'multimedia_listtodelete';
		$ui_page="pages/multimedia_listtodelete.php";
		break;

		case 'multimedia_delete';
		$ui_page="pages/multimedia_delete.php";
		break;


		case 'gold_listtodelete';
		$ui_page="pages/gold_listtodelete.php";
		break;

		case 'gold_delete';
		$ui_page="pages/gold_delete.php";
		break;

		case 'phd_listtodelete';
		$ui_page="pages/phd_listtodelete.php";
		break;

		// listtoupdate
		case 'coursedetail_listtoupdate';
		$ui_page="pages/coursedetail_listtoupdate.php";
		break;

		case 'subject_listtoupdate';
		$ui_page="pages/subject_listtoupdate.php";
		break;

		case 'lecture_listtoupdate';
		$ui_page="pages/lecture_listtoupdate.php";
		break;

		case 'examresult_listtoupdate';
		$ui_page="pages/examresult_listtoupdate.php";
		break;

		case 'photogallery_listtoupdate';
		$ui_page="pages/photogallery_listtoupdate.php";
		break;

		case 'coursetimetable_listtoupdate';
		$ui_page="pages/coursetimetable_listtoupdate.php";
		break;

		case 'member_listtoupdate';
		$ui_page="pages/member_listtoupdate.php";
		break;

		case 'mottos_listtoupdate';
		$ui_page="pages/mottos_listtoupdate.php";
		break;

		case 'faculties_listtoupdate';
		$ui_page="pages/faculties_listtoupdate.php";
		break;

		case 'news_listtoupdate';
		$ui_page="pages/news_listtoupdate.php";
		break;

		case 'magazine_listtoupdate';
		$ui_page="pages/magazine_listtoupdate.php";
		break;

		case 'multimedia_listtoupdate';
		$ui_page="pages/multimedia_listtoupdate.php";
		break;

		case 'gold_listtoupdate';
		$ui_page="pages/gold_listtoupdate.php";
		break;

		case 'phd_listtoupdate';
		$ui_page="pages/phd_listtoupdate.php";
		break;

		// update
		case 'coursedetail_update';
		$ui_page="pages/coursedetail_update.php";
		break;

		case 'subject_update';
		$ui_page="pages/subject_update.php";
		break;

		case 'lecture_update';
		$ui_page="pages/lecture_update.php";
		break;

		case 'examresult_update';
		$ui_page="pages/examresult_update.php";
		break;

		case 'photogallery_update';
		$ui_page="pages/photogallery_update.php";
		break;

		case 'coursetimetable_update';
		$ui_page="pages/coursetimetable_update.php";
		break;

		case 'member_update';
		$ui_page="pages/member_update.php";
		break;

		case 'mottos_update';
		$ui_page="pages/mottos_update.php";
		break;

		case 'faculties_update';
		$ui_page="pages/faculties_update.php";
		break;

		case 'news_update';
		$ui_page="pages/news_update.php";
		break;

		case 'magazine_update';
		$ui_page="pages/magazine_update.php";
		break;

		case 'multimedia_update';
		$ui_page="pages/multimedia_update.php";
		break;

		case 'gold_update';
		$ui_page="pages/gold_update.php";
		break;

		case 'phd_update';
		$ui_page="pages/phd_update.php";
		break;

		case 'user_changepassword';
		$ui_page="pages/user_changepassword.php";
		break;

		// entry
		case 'coursedetail_entry';
		$ui_page="pages/coursedetail_entry.php";
		break;

		case 'subject_entry';
		$ui_page="pages/subject_entry.php";
		break;

		case 'lecture_entry';
		$ui_page="pages/lecture_entry.php";
		break;

		case 'examresult_entry';
		$ui_page="pages/examresult_entry.php";
		break;

		case 'photogallery_entry';
		$ui_page="pages/photogallery_entry.php";
		break;

		case 'coursetimetable_entry';
		$ui_page="pages/coursetimetable_entry.php";
		break;

		case 'member_entry';
		$ui_page="pages/member_entry.php";
		break;

		case 'mottos_entry';
		$ui_page="pages/mottos_entry.php";
		break;

		case 'faculties_entry';
		$ui_page="pages/faculties_entry.php";
		break;

		case 'news_entry';
		$ui_page="pages/news_entry.php";
		break;

		case 'magazine_entry';
		$ui_page="pages/magazine_entry.php";
		break;

		case 'multimedia_entry';
		$ui_page="pages/multimedia_entry.php";
		break;

		case 'gold_entry';
		$ui_page="pages/gold_entry.php";
		break;

		case 'phd_entry';
		$ui_page="pages/phd_entry.php";
		break;

		case 'user_entry';
		$ui_page="pages/user_entry.php";
		break;

		case 'main';
		$ui_page="pages/main.php";
		break;

		case 'logout';
		$ui_page="pages/logout.php";
		break;
		
		case 'view_video';
		$ui_page="pages/view_video.php";
		break;
		
		case 'view';
		$ui_page="pages/view.php";
		break;
		
		case 'magazine_view';
		$ui_page="pages/magazine_view.php";
		break;
		
		case 'secure_magazine';
		$ui_page="pages/secure_magazine.php";
		break;
		
		case 'news_view';
		$ui_page="pages/news_view.php";
		break;
		
		case 'faculties_view';
		$ui_page="pages/faculties_view.php";
		break;
		
		case 'mottos_view';
		$ui_page="pages/mottos_view.php";
		break;
		
		case 'organization_view';
		$ui_page="pages/organization_view.php";
		break;
		
		case 'member_view';
		$ui_page="pages/member_view.php";
		break;
		
		case 'gallery_view';
		$ui_page="pages/gallery_view.php";
		break;
		
		case 'diploma_view';
		$ui_page="pages/diploma_view.php";
		break;

		default:
		$ui_page="pages/login.php";
		break;
	}
?>
