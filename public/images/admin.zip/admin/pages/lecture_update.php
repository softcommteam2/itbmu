<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;                  
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function setfocus()
{
  document.form.lecname.focus();
}
</script>
</head>
<body id="top"  onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Lecture  Update Form</h3><br>
      <p class="nospace">
      <?php
    		$lectureid=$_GET['del'];
    		$query="SELECT * FROM  tbl_lecture WHERE lecid='$lectureid'";
    		$count = $itbmu->query($query)or die($itbmu->error);
    		while ($row = $count->fetch_assoc()) {
     	?>
        <form action="#" method="post" name="form" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="lecno">Lec No </label></td>
              <td><input type="text" name="lecno" id="lecno" value="<?php echo $row['lecid']; ?>" size="30" required readonly="readonly"></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="lecname">Name <span>*</span></label></td>
              <td><input type="text" name="lecname" id="lecname" value="<?php echo $row['lecturename']; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="lecemail">Email<span>*</span></label></td>
              <td><input type="text" name="lecemail" id="lecemail" value="<?php echo $row['lecemail']; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="lecaddress">Address</label></td>
              <td>
              <textarea name="lecaddress" id="lecaddress" cols="32" rows="3" required><?php echo $row['address']; ?></textarea>
              </td>
            </tr>
            <tr height="50">
              <td><label for="eyear">Phone</label></td>
              <td><input type="text" name="lecphone" id="eyear" value="<?php echo $row['phone']; ?>" size="30" required></td>
            </tr>
              <td>&nbsp;</td>
              <td><input type="submit" name="lecupdate" value="Update"><br><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
        <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>