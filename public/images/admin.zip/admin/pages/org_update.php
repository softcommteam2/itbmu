<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");

//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$odate=date('l F j, Y');

$_REQUEST['message']="";
$message=$_REQUEST['message'];

?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function checknull()
{
  if(document.getElementById("name").value=="")
  {
    window.alert("Please enter Name");
    document.getElementById("name").focus();
    return false;
  }
  else
  {
    return true;
  }
}
function setfocus()
{
  document.form.name.focus();
}
</script>
</head>
<body id="top" onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Organization Update Form</h3><br>
      <p class="nospace">
      <?php
        $org=$_GET['del'];
        $query="SELECT * FROM tbl_organization WHERE id='$org'";
        $count = $itbmu->query($query)or die($itbmu->error);
        while ($row = $count->fetch_assoc()) {
          $rank=$row['rank'];
      ?>
        <form name="form" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="name">Name </label></td>
              <td><input type="text" name="name" id="name" value="<?php echo $row['name']; ?>" size="50" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="rank">Rank </label></td>
              <td>
                <select name="rank" id="rank">
                  <option value="Rector"
                    <?php
                      if ($row['rank']=='Rector') {
                        echo "selected='selected'";

                      }
                     ?>
                  >Rector</option>
                  <option value="Pro-Rector" <?php
                    if ($row['rank']=='Pro-Rector') { echo "selected='selected'";
                    }
                   ?>
                   >Pro-Rector </option>
                  <option value="Dean"
                  <?php
                    if ($row['rank']=='Dean') { echo "selected='selected'";
                    }
                   ?>
                  >Dean</option>
                  <option value="Professor"
                  <?php
                    if ($row['rank']=='Professor') { echo "selected='selected'";
                    }
                   ?>
                  >Professor </option>
                </select>
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="photo">Photo <span>*</span></label></td>
              <td><input type="text" name="ophoto" id="ophoto"  size="50" readonly value="<?php echo $row['photo']; ?>">
              <br>
              <img src="index.php?page=organization_view&file=<?php echo $row['photo']; ?>" style="width:100px; height:80px;"><br> <br>
              <input type="file" name="photo" id="photo"  size="30"></td>
            </tr>
            <tr height="50">
              <td><label for="biography">Biography <span>*</span></label></td>
              <td>
                <div id="sample">
                  <script type="text/javascript" src="richtext/nicEdit.js"></script>
                  <script type="text/javascript">
                    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
                  </script>
                <textarea name="biography" id="biography" style="width: 650px; height: 100px;"><?php echo $row['biography']; ?></textarea>
                </div>
              <!-- <textarea name="biography" id="biography" required rows="8" cols="50"></textarea> -->
              <!-- <input type="text" name="biography" id="biography"  size="30" required> -->
              </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="orgupdate" value="Update" onclick="return checknull()"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
        <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
