<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="content">
      <h1>Export Student File List</h1>
      <div class="scrollable">
        <table>
          <thead>
            <tr style="font-size:12px;">
              <th align="center">No</th>
              <th align="center">File Name</th>
              <th align="center">Export Date</th>
              <th align="center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
			
			
			
			
			$stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT id,filename,exportdate FROM tbl_studentexport");
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		 $stmt->bind_result($id, $filename,$exportdate);
		while($stmt->fetch())
			
			
              {
              
            ?>
            <tr>
              <td align="right"><?php echo $id;?></td>
              <td><?php echo $filename;?></td>
              <td><?php echo $exportdate;?></td>
              <td><a href="../admin/<?php echo $filename; ?>">Download</a></td>
            </tr>
            <?php
           
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
