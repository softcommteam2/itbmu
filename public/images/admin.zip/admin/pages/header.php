<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid="";
//$uid = $_SESSION['uid'];

$uid = (!empty($_SESSION['uid']) ? $_SESSION['uid'] : "");
?>

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php
  $sql = "SELECT user FROM tbl_user WHERE uid='$uid'";
  $result = $itbmu->query($sql)or die($itbmu->error);
  $row = $result->fetch_assoc();
?>
<?php
  if($uid!="")
  {
?>
<div class="wrapper row1">
  <header id="header" class="hoc clear">
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><img src="../images/demo/adminlogo.png"><a href="#"><!-- Tharavāda Buddhist Missionary University --></a></h1>
    </div>
    <div id="quickinfo" class="fl_right">

      <ul class="nospace inline">
        <li><strong>Welcome</strong></li>
        <li><strong><?php echo $row['user']; ?></strong></li>
      </ul>

       <ul class="nospace inline">
        <li><a href="index.php?page=logout"><strong>Log Out</strong></a></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </header>
</div>
<?php
  }else{}
?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php
  if($uid!="")
  {
?>
<div class="wrapper row2">
  <nav id="mainav" class="hoc clear">
    <!-- ################################################################################################ -->
    <ul class="clear">
      <li class="active"><a href="index.php?page=main">Home</a></li>
      <li><a class="drop" href="#">Entry</a>
        <ul>
          <li><a href="index.php?page=phd_entry">Ph.D Holder</a></li>
          <li><a href="index.php?page=gold_entry">Gold Holder</a></li>
          <li><a href="index.php?page=multimedia_entry">Multimedia</a></li>
          <li><a href="index.php?page=magazine_entry">Magazine</a></li>
          <li><a href="index.php?page=news_entry">News & Events</a></li>
          <li><a href="index.php?page=faculties_entry">Faculties</a></li>
          <li><a href="index.php?page=mottos_entry">Mottos</a></li>
          <li><a href="index.php?page=organization_entry">Organization</a></li>
          <li><a href="index.php?page=member_entry">Member</a></li>
          <li><a href="index.php?page=activitytitle_entry">Activity Title</a></li>
          <li><a href="index.php?page=photogallery_entry">Activity</a></li>
          <li><a href="index.php?page=lecture_entry">Lecture</a></li>
          <li><a href="index.php?page=subject_entry">Subject</a></li>
          <li><a href="index.php?page=coursetimetable_entry">Course Year Timetable</a></li>
          <li><a href="index.php?page=coursedetail_entry">Course Year Timetable detail</a></li>
          <li><a href="index.php?page=examresult_entry">Exam Result</a></li>
        </ul>
      </li>
      <li><a class="drop" href="#">Update</a>
        <ul>
          <li><a href="index.php?page=phd_listtoupdate">Ph.D Holder</a></li>
          <li><a href="index.php?page=gold_listtoupdate">Gold Holder</a></li>
          <li><a href="index.php?page=multimedia_listtoupdate">Multimedia</a></li>
          <li><a href="index.php?page=magazine_listtoupdate">Magazine</a></li>
          <li><a href="index.php?page=news_listtoupdate">News & Events</a></li>
          <li><a href="index.php?page=faculties_listtoupdate">Faculties</a></li>
          <li><a href="index.php?page=mottos_listtoupdate">Mottos</a></li>
          <li><a href="index.php?page=organization_listtoupdate">Organization</a></li>
          <li><a href="index.php?page=member_listtoupdate">Member</a></li>
          <li><a href="index.php?page=activitytitle_listtoupdate">Activity Title</a></li>
          <li><a href="index.php?page=photogallery_listtoupdate">Activity</a></li>
          <li><a href="index.php?page=lecture_listtoupdate">Lecture</a></li>
          <li><a href="index.php?page=subject_listtoupdate">Subject</a></li>
          <li><a href="index.php?page=coursetimetable_listtoupdate">Course Year Timetable</a></li>
          <li><a href="index.php?page=coursedetail_listtoupdate">Course Year Timetable detail</a></li>
          <li><a href="index.php?page=examresult_listtoupdate&Pg=1">Exam Result</a></li>
        </ul>
      </li>
       <li><a class="drop" href="#">Delete</a>
        <ul>
          <li><a href="index.php?page=phd_listtodelete">Ph.D Holder</a></li>
          <li><a href="index.php?page=gold_listtodelete">Gold Holder</a></li>
          <li><a href="index.php?page=multimedia_listtodelete">Multimedia</a></li>
          <li><a href="index.php?page=magazine_listtodelete">Magazine</a></li>
          <li><a href="index.php?page=news_listtodelete">News & Events</a></li>
          <li><a href="index.php?page=faculties_listtodelete">Faculties</a></li>
          <li><a href="index.php?page=mottos_listtodelete">Mottos</a></li>
          <li><a href="index.php?page=organization_listtodelete">Organization</a></li>
          <li><a href="index.php?page=member_listtodelete">Member</a></li>
          <li><a href="index.php?page=activitytitle_listtodelete">Activity Title</a></li>
          <li><a href="index.php?page=photogallery_listtodelete">Activity</a></li>
          <li><a href="index.php?page=lecture_listtodelete">Lecture</a></li>
          <li><a href="index.php?page=subject_listtodelete">Subject</a></li>
          <li><a href="index.php?page=coursetimetable_listtodelete&Pg=1">Course Year Timetable</a></li>
          <li><a href="index.php?page=coursedetail_listtodelete&Pg=1">Course Year Timetable detail</a></li>
          <li><a href="index.php?page=examresult_listtodelete&Pg=1">Exam Result</a></li>
        </ul>
      </li>
       <li><a class="drop" href="#">List</a>
        <ul>
          <li><a href="index.php?page=phd_list">Ph.D Holder</a></li>
          <li><a href="index.php?page=gold_list">Gold Holder</a></li>
          <li><a href="index.php?page=multimedia_list">Multimedia</a></li>
          <li><a href="index.php?page=magazine_list">Magazine</a></li>
          <li><a href="index.php?page=news_list">News & Events</a></li>
          <li><a href="index.php?page=faculties_list">Faculties</a></li>
          <li><a href="index.php?page=mottos_list">Mottos</a></li>
          <li><a href="index.php?page=organization_list">Organization</a></li>
          <li><a href="index.php?page=member_list">Member</a></li>
          <li><a href="index.php?page=subscribe_list">Subscribe Mail</a></li>
          <li><a href="index.php?page=activitytitle_list">Activity Title</a></li>
          <li><a href="index.php?page=photogallery_list">Activity</a></li>
          <li><a href="index.php?page=lecture_list">Lecture</a></li>
          <li><a href="index.php?page=subject_list">Subject</a></li>
          <li><a href="index.php?page=coursetimetable_list">Course Year Timetable</a></li>
          <li><a href="index.php?page=coursedetail_list">Course Year Timetable detail</a></li>
          <li><a href="index.php?page=examresult_list">Exam Result</a></li>
        </ul>
      </li>
       <li><a class="drop" href="#">User</a>
        <ul>
          <li><a href="index.php?page=user_entry">Create New Account</a></li>
          <li><a href="index.php?page=user_changepassword">Change Password</a></li>
          <li><a href="index.php?page=user_list">User List</a></li>
        </ul>
      </li>
      <li><a class="drop" href="#">Export</a>
        <ul>
          <li><a href="index.php?page=export_studentlist">Export Student </a></li>
          <li><a href="index.php?page=export_studentfilelist">Export Student File List</a></li>
          <li><a href="index.php?page=export_subscribemaillist">Export Subscribe Mail </a></li>
          <li><a href="index.php?page=export_subscribemailfilelist">Export Subscribe Mail File List </a></li>
        </ul>
      </li>
      <li><a class="drop" href="#">Import</a>
        <ul>
          <li><a href="index.php?page=book_list">Book List</a></li>
        </ul>
      </li>
      <li><a class="drop" href="#">Help</a>
        <ul>
          <li><a href="index.php?page=usermanual">User Manual</a></li>
        </ul>
      </li>
      <!-- <li><a href="#">FAQ</a></li> -->
     <!--  <li><a href="#">Link Text</a></li>
      <li><a href="#">Link Text</a></li>
      <li><a href="#">Long Link Text</a></li> -->
    </ul>
    <!-- ################################################################################################ -->
  </nav>
</div>
<?php
  }else{}
?>
