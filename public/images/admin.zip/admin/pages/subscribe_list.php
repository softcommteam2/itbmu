<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
		echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharav��da Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
      <h1>Subscribe Mail List</h1>
<!--
<form class="" action="index.php?page=phd_list" method="post">
   
   <table>
           <tr height="50">
              <td><label for="name">Name </label></td>
              <td><input type="text" name="name" id="name" size="40"></td>
              <td colspan="4"><button type="submit" name="button">Search</button></td>
            </tr>
    </table>
</form>-->

     
      <table id="example"  cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
              <th align="center">No</th>
              <th align="center">Name</th>
              <th align="center">Email</th>
              <th align="center">Submit Date</th>
            </tr>
        </thead>
        
       
        <tbody>
          <?php
                                     //  $where = array();
                                    //   if (!empty($_REQUEST['name']) ? $_REQUEST['name'] : "")
	                            //   {
			                     //   $_SESSION['name'] = $_REQUEST['name'];
			                     //   $where[] = "name  LIKE '%".$_SESSION['name']."%'";
		                    //   }

                                        $sql ="SELECT * FROM tbl_subscribe";
                                        $res= $itbmu->query($sql)or die($itbmu->error);
                                     //   if(count($where)) {
						//$sql .= ' WHERE '.implode(' AND ', $where);
				//	}
                                        $count = $itbmu->query($sql)or die($itbmu->error);
					$num = $count->num_rows;
                                        while ($row = $res->fetch_assoc())    
                                        {
                                         	 $name=$row['name'];
          	                                 $email=$row['email'];
          	                                 $createdate=$row['createdate'];
                                                 if ($row !== "" ) { @$no++; }
          	                      ?>
            <tr>
              <td align="right"><?php echo $no;?></td>
              <td><?php echo $name;?></td>
              <td><?php echo $email;?></td>
              <td><?php echo $createdate;?></td>
             </tr>
            <?php } ?>
        </tbody>
        
    </table>
       
  <br>
        <div align="right">
		<form method="POST" action="pages/subscribemaillist.php"  >
			<?php 
                                 if ($num != 0): $_SESSION['id_array'] = $id_array; 
                        ?>
				<button type="submit" style="background-color: #008CBA; color:#ffffff; border-color:#008CBA; padding:8px; width:80px;">Print</button>
				<?php endif; ?>
		</form>
        </div>
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": true,
 "scrollY":        "200px",
 "scrollCollapse": true,

 
        
        
  });
 
	
} );
</script>
</html>