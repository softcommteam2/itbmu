<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;                  
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Course Year Timetable Update Form</h3><br>
      <p class="nospace">
       <?php

 $course=$_GET['del'];

 $query="SELECT * FROM tbl_coursetimetable WHERE id='$course'";
 //echo $query;
								$count = $itbmu->query($query)or die($itbmu->error);

								while ($row = $count->fetch_assoc()) {

									//echo $row['create_date'];


 ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="coursename">Course Name <span>*</span></label></td>
              <td><input type="text" name="coursename" id="coursename" value="<?php echo $row['coursename'] ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="opendate">Open Date <span>*</span></label></td>
              <td><input type="text" name="opendate" id="opendate" value="<?php echo $row['opendate'] ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="opentime">Open Time <span>*</span></label></td>
              <td><input type="text" name="opentime" id="opentime" value="<?php echo $row['opentime'] ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="openday">Open Day <span>*</span></label></td>
              <td><input type="text" name="openday" id="openday" value="<?php echo $row['openday'] ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="courseupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
        <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>