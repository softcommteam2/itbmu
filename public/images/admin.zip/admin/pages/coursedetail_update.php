<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function setfocus()
{
  document.form.rollno.focus();
}
</script>
</head>
<body id="top"  onload="setfocus()">

<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Course Year Timetable Detail Update Form</h3><br>
      <p class="nospace">
      <?php
        $coursedetailid=$_GET['del'];
        $query="SELECT * FROM tbl_coursetimetabledetail WHERE coursetimetableid='$coursedetailid'";
				$count = $itbmu->query($query)or die($itbmu->error);
				while ($row = $count->fetch_assoc()) {
					$tt=$row['cdtday'];
					$tc=$row['cdttime'];
					$ta=$row['courseno'];
					$tb=$row['semester'];
					$td=$row['lecturehall']
      ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
           <tr height="50" valign="middle">
              <td><label for="opendate">Course Year<span>*</span></label></td>
              <td><input type="yeare" name="year" id="year" value="<?php echo $row['courseyear']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="coursename">Course Name <span>*</span></label></td>
              <td>
              <?php
                $courseid=$row['id'];
                $b="SELECT * FROM  tbl_coursetimetable WHERE  id='$courseid'";
                $bq = $itbmu->query($b)or die($itbmu->error);
              	while ($brow = $bq->fetch_array()) {
              	$ba=$brow['coursename'];
              	$bai=$brow['id'];
                }
                ?>
                <select name="coursename" id="coursename">
                  <option value="<?php echo $bai; ?>" ><?php echo $ba; ?></option>
                    <?php
              				$qry="SELECT * FROM tbl_coursetimetable";
              				$query = $itbmu->query($qry)or die($itbmu->error);
              				while ($row = $query->fetch_assoc()) {
              					?>
                          <option value="<?php echo $row['id']; ?>"><?php echo $row['coursename']; ?></option>
                      <?php
              				}
              			?>
                    </select></td>
                </tr>

            <tr height="50">
              <td><label for="semester">Semester <span>*</span></label></td>
              <td><select name="semester" id="semester" >
                <option value="First Semester"
                <?php if ($tb=="First Semester"){
        					echo "selected='selected'";
        				}
        					?>
                        >First Semester</option>
                        <option value="Second Semester"
                        <?php if ($tb=="Second Semester"){
        					echo "selected='selected'";
        				}
        					?>
                >Second Semester</option>
              </select></td>
            </tr>
            <tr height="50">
              <td><label for="subject">Course No <span>*</span></label></td>
              <td>
              <select name="subject" id="subject">
                  <?php
                    $qry1="SELECT distinct courseno FROM tbl_course GROUP BY courseno";
                    $query1 = $itbmu->query($qry1)or die($itbmu->error);
                    while ($row1 = $query1->fetch_assoc()) {
                      $courseno=$row1['courseno'];
                  ?>
                  <option value="<?php echo $courseno; ?>"
                    <?php if ($ta==$courseno){
                      echo "selected='selected'";
                    }
                    ?>
                  ><?php echo $courseno; ?></option>
                  <?php
                    }
                  ?>
                </select>

              <!-- <select name="subject" id="subject" >
                <option value="vin"
                  <?php if ($ta=="vin"){
            					echo "selected='selected'";
            				}
            					?>
                    >Vin-111</option>
                    <option value="sut"
                    <?php if ($ta=="sut"){
            					echo "selected='selected'";
            				}
            					?>
                        >Sut-112</option>
                        <option value="abh"
                        <?php if ($ta=="abh"){
            					echo "selected='selected'";
            				}
            					?>
                            >Abh-113</option>
                            <option value="hist"
                            <?php if ($ta=="hist"){
            					echo "selected='selected'";
            				}
            					?>
                            >Hist-314</option>
                            <option value="pali"
                            <?php if ($ta=="pali"){
            					echo "selected='selected'";
            				}
            					?>
                            >Pali-411</option>
                            <option value="mya"
                            <?php if ($ta=="mya"){
            					echo "selected='selected'";
            				}
            					?>
                            >Mya-412</option>
                            <option value="dha"
                            <?php if ($ta=="dha"){
            					echo "selected='selected'";
            				}
            					?>
                            >Dha-211</option>
                            <option value="sam"
                            <?php if ($ta=="sam"){
            					echo "selected='selected'";
            				}
            					?>
                            >Sam-212</option>
                            <option value="vip"
                            <?php if ($ta=="vip"){
            					echo "selected='selected'";
            				}
            					?>
                            >Vip-213</option>
                            <option value="reli"
                            <?php if ($ta=="reli"){
            					echo "selected='selected'";
            				}
            					?>
                            >Reli-311</option>
                            <option value="miss"
                            <?php if ($ta=="miss"){
            					echo "selected='selected'";
            				}
            					?>
                            >Miss-313</option>
                            <option value="eng"
                            <?php if ($ta=="eng"){
            					echo "selected='selected'";
            				}
            					?>
                >Eng-413</option>
              </select> -->
              </td>
            </tr>
            <tr height="50">
              <td><label for="openday">Open Day <span>*</span></label></td>
              <td>
              <select name="day" id="day" >
                <option value="Monday"
                <?php if ($tt=="Monday"){
                					echo "selected='selected'";
                				}
                					?>
                                >Monday</option>

                                  <option value="Tueday"
                <?php if ($tt=="Tueday"){
                					echo "selected='selected'";
                				}
                					?>
                                >Tueday</option>
                                  <option value="Wednesday"
                <?php if ($tt=="Wednesday"){
                					echo "selected='selected'";
                				}
                					?>
                                >Wednesday</option>
                                  <option value="Thursday"
                <?php if ($tt=="Thursday"){
                					echo "selected='selected'";
                				}
                					?>
                                >Thursday</option>
                                  <option value="Friday"
                <?php if ($tt=="Friday"){
                					echo "selected='selected'";
                				}
            					?>
                            >Friday</option>
                  </select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="opentime">Open Time <span>*</span></label></td>
              <td>
              <select name="time" id="time" >
                <option value="08:00 AM to 08:50 AM"
                <?php if ($tc=="08:00 AM to 08:50 AM"){
                					echo "selected='selected'";
                				}
                					?>
                                >08:00 AM to 08:50 AM</option>
                                  <option value="09:00 AM to 09:50 AM"
                <?php if ($tc=="09:00 AM to 09:50 AM"){
                					echo "selected='selected'";
                				}
                					?>
                                >09:00 AM to 09:50 AM</option>

                                <option value="08:00 AM to 09:50 AM"
              <?php if ($tc=="08:00 AM to 09:50 AM"){
                        echo "selected='selected'";
                      }
                        ?>
                              >08:00 AM to 09:50 AM</option>

                                  <option value="10:00 AM to 10:50 AM"
                <?php if ($tc=="10:00 AM to 10:50 AM"){
                					echo "selected='selected'";
                				}
                					?>
                                >10:00 AM to 10:50 AM</option>
                                  <option value="13:00PM to 13:50PM"
                <?php if ($tc=="13:00 PM to 13:50 PM"){
                					echo "selected='selected'";
                				}
                					?>
                                >13:00 PM to 13:50 PM</option>
                                  <option value="14:00 PM to 14:50 PM"
                <?php if ($tc=="14:00 PM to 14:50 PM"){
                					echo "selected='selected'";
                				}
                					?>
                                >14:00 PM to 14:50 PM</option>
                                     <option value="15:00 PM to 15:50 PM"
                <?php if ($tc=="15:00 PM to 15:50 PM"){
                					echo "selected='selected'";
                				}
                					?>
                >15:00 PM to 15:50 PM</option>
            </select> </td></tr>
            <tr height="50" valign="middle">
              <td><label for="opendate">Lecture Hall<span>*</span></label></td>
              <td><select name="hall" id="hall" >
                <option value="1"
                <?php if ($td=="1"){
        					echo "selected='selected'";
        				}
        					?>
                >1</option>
                 <option value="2"
                <?php if ($td=="2"){
        					echo "selected='selected'";
        				}
        					?>
                >2</option>
                <option value="3(A)"
                <?php if ($td=="3(A)"){
        					echo "selected='selected'";
        				}
        					?>
                >3(A)</option>
                <option value="3(B)"
                <?php if ($td=="3(B)"){
        					echo "selected='selected'";
        				}
        					?>
                >3(B)</option>
                 <option value="4"
                <?php if ($td=="4"){
        					echo "selected='selected'";
        				}
        					?>
                >4</option>
              </select>
             </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="ccupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
    <?php  } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
