<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Activity Update Form</h3><br>
      <p class="nospace">
      <?php
        $pgid=$_GET['del'];
        $query="SELECT * FROM  tbl_photogallery WHERE id='$pgid'";
        $count = $itbmu->query($query)or die($itbmu->error);
        while ($row = $count->fetch_assoc()) {
          $titleid=$row['titleid'];
      ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="label1">Activity Title </label></td>
              <td>
              <?php
                $b="SELECT * FROM  tbl_activitytitle WHERE titleid='$titleid'";
                $bq = $itbmu->query($b)or die($itbmu->error);
                while ($brow = $bq->fetch_array()) {
                  $activitytitle=$brow['activitytitle']; 
                }
              ?>
                <select name="label1" id="label1">
                    <option value="<?php echo $titleid; ?>"><?php echo $activitytitle; ?></option>
                      <?php
                          $qry="SELECT * FROM tbl_activitytitle"; 
                          $query = $itbmu->query($qry)or die($itbmu->error);

                          while ($row1 = $query->fetch_assoc()) {
                            $titleid1=$row1['titleid'];
                            $activitytitle1=$row1['activitytitle'];
                      ?>    
                      <option value="<?php echo $titleid1; ?>"><?php echo $activitytitle1; ?></option>
                      <?php
                          }
                      ?>
                </select>
              </td>
            </tr>

            <tr height="50" valign="middle">
              <td><label for="photo">Photo </label></td>
              <td>
                <input type="text" name="photo" id="photo" value="<?php echo $row['photo']; ?>" size="30"  readonly="readonly">
                <br>
                <img src="index.php?page=gallery_view&file=<?php echo $row['photo']; ?>" style="width:100px; height:80px;">
                <br> 
                <input type="file" name="nphoto"> </td>
            </tr>
            <!-- <tr height="50" valign="middle">
              <td><label for="plabel">Label  <span>*</span></label></td>
              <td><input type="text" name="plabel" id="plabel" value="<?php echo $row['label']; ?>" size="30" required></td>
            </tr> -->
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="pgupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
      <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>