<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/insert_process.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function setfocus()
{
  document.form.courseno.focus();
}
</script>
</head>
<body id="top"  onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Subject Entry Form</h3><br>
      <p class="nospace">
        <form name="form" action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="courseno">Course No </label></td>
              <td><input type="text" name="courseno" id="courseno" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="subjectname">Subject Name <span>*</span></label></td>
              <td><input type="text" name="subjectname" id="subjectname" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="lectureby">Lecture By <span>*</span></label></td>
              <td>	
                <select name="lectureby" id="lectureby">
                    <option value="">----Select Lecture----</option>
                      <?php
  												$qry="SELECT * FROM tbl_lecture"; 
  												$query = $itbmu->query($qry)or die($itbmu->error);

  												while ($row = $query->fetch_assoc()) {
  										?>		
                      <option value="<?php echo $row['lecid']; ?>"><?php echo $row['lecturename']; ?></option>
                      <?php
  												}
  						        ?>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="semester">Semester <span>*</span></label></td>
              <td>
                <select name="semester" id="semester">
                  <option value="First Semester">First Semester </option>
                  <option value="Second Semester">Second Semester </option>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="coursename">Course Name <span>*</span></label></td>
              <td>	
                <select name="coursename" id="coursename">
                    <option value="">----Select Course Name----</option>
                  	<?php
  											$qry="SELECT * FROM tbl_coursetimetable"; 
  											$query = $itbmu->query($qry)or die($itbmu->error);
  											while ($row = $query->fetch_assoc()) {
										?>		
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['coursename']; ?></option>
                    <?php
												}
								    ?>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="subsave" value="Save"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>