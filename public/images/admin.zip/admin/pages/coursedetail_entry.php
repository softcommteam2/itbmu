<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/insert_process.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Course Year Timetable Detail Entry Form</h3><br>
      <p class="nospace">
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="courseyear">Course Year<span>*</span></label></td>
              <td><input type="text" name="courseyear" id="courseyear" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="coursename">Course Name <span>*</span></label></td>
              <td>
                <select name="coursename" id="coursename">
                    <option value="">----Select Course Name----</option>
                    	<?php
												$qry="SELECT * FROM tbl_coursetimetable";
												$query = $itbmu->query($qry)or die($itbmu->error);
												while ($row = $query->fetch_assoc()) {
											?>
                      <option value="<?php echo $row['id']; ?>"><?php echo $row['coursename']; ?></option>
                      <?php
												}
								      ?>
                </select>
              </td>
            </tr>

            <tr height="50">
              <td><label for="semester">Semester <span>*</span></label></td>
              <td>
                <select name="semester" id="semester">
                  <option value="">----Select Semester----</option>
          	      <option value="First Semester">First Semester</option>
                  <option value="Second Semester">Second Semester----</option>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="courseno">Course No <span>*</span></label></td>
              <td>
                <select name="courseno" id="courseno">
                  <option value="">----Select Subject----</option>
                  <?php
                    $qry1="SELECT distinct courseno FROM tbl_course GROUP BY courseno";
                    $query1 = $itbmu->query($qry1)or die($itbmu->error);
                    while ($row1 = $query1->fetch_assoc()) {
                      $courseno=$row1['courseno'];
                  ?>
                  <option value="<?php echo $courseno; ?>"><?php echo $courseno; ?></option>
                  <?php
                    }
                  ?>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="openday">Day <span>*</span></label></td>
              <td>
                <select name="openday" id="openday">
                  <option value="">----Select Day----</option>
                  <option value="Monday">Monday</option>
                  <option value="Tuesday">Tuesday</option>
                  <option value="Wednesday">Wednesday</option>
                  <option value="Thursday">Thursday</option>
                  <option value="Friday">Friday</option>
              	</select>
              </td>
            </tr>
            <tr height="50">
              <td><label for="opentime">Time <span>*</span></label></td>
              <td>
                <select name="opentime" id="opentime">
                  <option value="">----Select Subject----</option>
                  <option value="08:00 AM to 08:50 AM">08:00AM to 08:50AM</option>
                  <option value="09:00 AM to 09:50 AM">09:00AM to 09:50AM</option>
                  <option value="08:00 AM to 09:50 AM">08:00AM to 09:50AM</option>
                  <option value="10:00 AM to 10:50 AM">10:00AM to 10:50AM</option>
                  <option value="13:00 PM to 13:50 PM">13:00PM to 13:50PM</option>
                  <option value="14:00 PM to 14:50 PM">14:00PM to 14:50PM</option>
                  <option value="15:00 PM to 15:50 PM">15:00PM to 15:50PM</option>

                </select>
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="hall">Lecture Hall<span>*</span></label></td>
              <td>
                <select name="hall" id="hall">
                  <option value="">----Select Hall----</option>
                   <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3(A)">3(A)</option>
                  <option value="3(B)">3(B)</option>
                   <option value="4">4</option>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="ccsave" value="Save"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>

        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
