<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharav��da Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
   <h1>Gold Holder List</h1>
   <form class="" action="index.php?page=gold_list" method="post">
   
   <table>
           <tr height="50">
              <td><label for="name">Name </label></td>
              <td><input type="text" name="name" id="name" size="40"></td>
               <td><label for="rollno">Roll No. </label></td>
              <td><input type="text" name="rollno" id="rollno" size="40"></td>
            </tr>
           
            
            <tr height="50">
              <td><label for="eyear">Year </label></td>
              <td><input type="text" name="eyear" id="eyear" size="40"></td>
              <td><label for="country">Country</label></td>
              <td><input type="text" name="country" id="country" size="40" ></td>
            </tr>
             
            <tr height="50">
              
              <td colspan="4"><button type="submit" name="button">Search</button></td>
            </tr>
          
          </table>
   </form>
    
     
     
      <table id="example"  cellspacing="0" width="100%">
									<thead>
										<tr style="font-size:12px;">
											<th align="center" width="10%">Sr. No.</th>
              								<th align="center">Roll No.</th>
              								<th align="center">Name</th>
              								<th align="center">Year</th>
              								<th align="center">Country</th>
										</tr>
									</thead>
									<?php
									$where = array();

									if (!empty($_REQUEST['name']) ? $_REQUEST['name'] : "")
									{
										$_SESSION['name'] = $_REQUEST['name'];
										$where[] = "name	LIKE '%".$_SESSION['name']."%'";
									}

								if (!empty($_REQUEST['rollno']) ? $_REQUEST['rollno'] : "")
									{
										$_SESSION['rollno'] = $_REQUEST['rollno'];
										$where[] = "rollno   LIKE '%".$_SESSION['rollno']."%'";
									}
									
									if (!empty($_REQUEST['eyear']) ? $_REQUEST['eyear'] : "")
									{
										$_SESSION['eyear'] = $_REQUEST['eyear'];
										$where[] = "goldyear	LIKE '%".$_SESSION['eyear']."%'";
									}
									
									if (!empty($_REQUEST['country']) ? $_REQUEST['country'] : "")
									{
										$_SESSION['country'] = $_REQUEST['country'];
										$where[] = "country	 LIKE '%".$_SESSION['country']."%'";
									}

									
									
									

									$sql = "SELECT * FROM tbl_gold";
									if(count($where)) {
										$sql .= ' WHERE '.implode(' AND ', $where);
									}
									$count = $itbmu->query($sql)or die($itbmu->error);
									$num = $count->num_rows;
									while ($row = $count->fetch_assoc()) {
										$id = $row['id'];
										$gsrno=$row['srno'];
          								$grollno=$row['rollno'];
          								$gname=$row['name'];
          								$gyear=$row['goldyear'];
          								$country=$row['country'];

										$id_array[]=$id;
										?>
										<tr>
											<td align="right"><?php echo $gsrno;?></td>
             								<td><?php echo $grollno;?></td>
              								<td><?php echo $gname;?></td>
              								<td align="center"><?php echo $gyear;?></td>
              								<td align="center"><?php echo $country;?></td>
													
											</tr>
                                            <?php
												}
												?>
										</table>
                                        <br>

        <div align="right">
											<form method="POST" action="pages/gold_holder_report_pdf.php"  >
												<?php if ($num != 0): $_SESSION['id_array'] = $id_array; ?>
													<button type="submit" style="background-color: #008CBA; color:#ffffff; border-color:#008CBA; padding:8px; width:80px;">Print</button>
												<?php endif; ?>
											</form>
										</div>
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>



<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": false,
"bInfo": false,
"bAutoWidth": false,
 "scrollY":        "200px",
 "scrollX": true,
        "scrollCollapse": true,
 
        
        
  });
 
	
} );
</script>

</html>