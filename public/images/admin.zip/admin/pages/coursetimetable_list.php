<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
		echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharav��da Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
   <h1>Course Year Timetable List</h1>
   <form class="" action="index.php?page=coursetimetable_list" method="post">
   
   <table>
           <tr height="50">
              <td><label for="name">Course Name </label></td>
              <td><input type="text" name="name" id="name" size="40"></td>
               
            </tr>
           
            
            
             
            <tr height="50">
              
              <td colspan="4"><button type="submit" name="button">Search</button></td>
            </tr>
          
          </table>
   </form>
    
     
     
      <table id="example"  cellspacing="0" width="100%">
									<thead>
										<tr style="font-size:12px;">
									<th align="center">Course Name</th>
              								<th align="center">Open Date</th>
              								<th align="center">Open Time</th>
              								<th align="center">Open Day</th>
										</tr>
									</thead>
									<?php
									$where = array();

									if (!empty($_REQUEST['name']) ? $_REQUEST['name'] : "")
									{
										$_SESSION['name'] = $_REQUEST['name'];
										$where[] = "coursename	 LIKE '%".$_SESSION['name']."%'";
									}
									$sql = "SELECT * FROM tbl_coursetimetable";
									if(count($where)) {
										$sql .= ' WHERE '.implode(' AND ', $where);
									}
									$count = $itbmu->query($sql)or die($itbmu->error);
									$num = $count->num_rows;
									while ($row = $count->fetch_assoc()) {
										$id = $row['id'];
										$coursename=$row['coursename'];
										$opendate=$row['opendate'];
										$opentime=$row['opentime'];
										$openday=$row['openday'];

										$id_array[]=$id;
										?>
										<tr>
											 <td><?php echo $coursename;?></td>
              								 <td align="center"><?php echo $opendate;?></td>
              								<td align="center"><?php echo $opentime;?></td>
              								<td align="center"><?php echo $openday;?></td>
													
											</tr>
                                            <?php
												}
												?>
										</table><br>

        <div align="right">
											<form method="POST" action="pages/course_year_timetable_report_pdf.php"  >
												<?php if ($num != 0): $_SESSION['id_array'] = $id_array; ?>
													<button type="submit" style="background-color: #008CBA; color:#ffffff; border-color:#008CBA; padding:8px; width:80px;">Print</button>
												<?php endif; ?>
											</form>
										</div>
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": false,
"bInfo": false,
"bAutoWidth": true,
 "scrollY":        "200px",
  "scrollCollapse": true,
 

 
        
        
  });
 
	
} );
</script>
</html>