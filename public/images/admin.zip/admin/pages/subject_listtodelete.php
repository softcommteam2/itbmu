<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
		echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script>
$('document').ready(function()
{
$(".select-all").click(function ()
{
$('.chk-box').attr('checked', this.checked)
});

$(".chk-box").click(function()
{
if($(".chk-box").length == $(".chk-box:checked").length)
{
$(".select-all").attr("checked", "checked");
}
else
{
$(".select-all").removeAttr("checked");
}
});
});

// dynamically redirects to specified page
function delete_records()
{
document.frm.action = "index.php?page=subject_delete";
document.frm.submit();
}
</script>
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
    <h1>Subject Delete List</h1>
       <form method="post"  name="frm" action="<?php $_SERVER['SCRIPT_NAME'];?>?page=subject_listtodelete&Pg=a">
     
      <table id="example"  cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
              <th></th>            
              <th align="center">Sub No</th>
              <th align="center" width="15%">Subject Name</th>
              <th align="center" width="20%">Lecture By</th>
              <th align="center">Semester</th>
              <th align="center" width="15%">Course Name</th>
            </tr>
        </thead>
        
       
        <tbody>
          				<?php
                                        $stmt = $itbmu->stmt_init();
   					$stmt->prepare("SELECT courseid,courseno,subject,lecid,semester,id FROM tbl_course");
   					$stmt->execute() or die($stmt->error);
   					$stmt->store_result();
   					$stmt->bind_result($subid,$subjectno,$subjectname,$lectureby,$semester,$coursename);
   					while($stmt->fetch())
					{
                                    		?>
            <tr>
              <td><input type="checkbox" name="chk[]" class="chk-box" value="<?php echo $subid; ?>" /></td>
              	<td><?php echo $subjectno;?></td>
              	<td><?php echo $subjectname;?></td>
             	<td><?php 
				//$uniid=$row['lecid'];
				$qry="SELECT * FROM tbl_lecture WHERE lecid='$lectureby'"; 
				$query = $itbmu->query($qry)or die($itbmu->error);
				while ($row1 = $query->fetch_assoc()) {
				echo $row1['lecturename'];  
	            }?>
	            </td>
              	<td><?php echo $semester;?></td>
             	<td><?php 
					//$subjectid=$row['id'];
					$qry="SELECT * FROM tbl_coursetimetable WHERE id='$coursename'"; 
					$query = $itbmu->query($qry)or die($itbmu->error);
					while ($row1 = $query->fetch_assoc()) {
			 		echo $row1['coursename'];  
             		}?>
             	</td>
            </tr>
            <?php } ?>
        </tbody>
        
    </table>
        <label id="actions">
			<button type="submit" onClick="delete_records();" alt="delete" class="btn">delete </button>
			</label>
     </form>
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": true,
 "scrollY":        "200px",
  "scrollCollapse": true,
 

 
        
        
  });
 
	
} );
</script>
</html>