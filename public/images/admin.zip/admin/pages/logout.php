<?php 

require_once('../connection/connection.php');
?>
<?php

	function dologout()
	{	
		if (isset($_SESSION['uid']))
		{
			session_unset();
			session_destroy();		
		}
		echo "<script language=\"javascript\">window.location.href=\"index.php\";</script>";

	}
	dologout();
	exit;


?>