<?php

error_reporting(0);

require_once("../connection/connection.php");

$chk = $_POST['chk'];
$chkcount = count($chk);

if(!isset($chk))
{
?>
<script>
alert('At least one checkbox Must be Selected !!!');
window.location.href = 'index.php?page=phd_listtodelete&Pg=a';
</script>
<?php
}
else
{
for($i=0; $i<$chkcount; $i++)
{
$del = $chk[$i];
$sql=$itbmu->query("DELETE FROM tbl_phd WHERE id=".$del);
}

if($sql)
{
?>
<script>
alert('<?php echo $chkcount; ?> Records Was Deleted !!!');
window.location.href='index.php?page=phd_listtodelete&Pg=a';
</script>
<?php
}
else
{
?>
<script>
alert('Error while Deleting , TRY AGAIN');
window.location.href='index.php?page=phd_listtodelete&Pg=a';
</script>
<?php
}

}
?>