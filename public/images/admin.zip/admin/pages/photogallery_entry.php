<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/insert_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Activity Entry Form</h3><br>
      <p class="nospace">
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="label1">Activity Title </label></td>
              <td>
                <select name="label1" id="label1">
                    <option value="">----Select Title----</option>
                      <?php
                          $qry="SELECT * FROM tbl_activitytitle"; 
                          $query = $itbmu->query($qry)or die($itbmu->error);

                          while ($row = $query->fetch_assoc()) {
                      ?>    
                      <option value="<?php echo $row['titleid']; ?>"><?php echo $row['activitytitle']; ?></option>
                      <?php
                          }
                      ?>
                </select>
              </td>
            </tr>

            <tr height="50" valign="middle">
              <td><label for="photo1">Photo </label></td>
              <td><input type="file" name="photo1" id="photo1" value="" size="30"></td>
            </tr>
           
            
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="save" value="Save"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>