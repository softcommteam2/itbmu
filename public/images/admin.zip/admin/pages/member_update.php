<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Member Update Form</h3><br>
      <p class="nospace">
      <?php
        $member=$_REQUEST['del'];
        $query="SELECT * FROM tbl_itbmumember WHERE id='$member'";
        $count = $itbmu->query($query)or die($itbmu->error);
        while ($row = $count->fetch_assoc()) {

      ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td width="300px"><label for="membername">Name <span>*</span></label></td>
              <td><input type="text" name="membername" id="membername" value="<?php echo $row['name']; ?>" size="30" required></td>
            </tr>
            <?php
              $stquery="SELECT Class FROM students WHERE StudentID='$member'";
              $stcount = $itbmu->query($stquery)or die($itbmu->error);
              $row1 = $stcount->fetch_assoc();
            ?>
            <tr height="50" valign="middle">
              <td width="300px"><label for="class">Class <span>*</span></label></td>
              <td><input type="text" name="class" id="class" value="<?php echo $row1['Class']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="photo">Photo <span>*</span></label></td>
              <td>
                <input type="text" name="photo" id="photo" value="<?php echo $row['photo']; ?>" size="30" readonly>
                <br>
                <img src="index.php?page=member_view&file=<?php echo $row['photo']; ?>" style="width:100px; height:100px;">
                <br>
                <input type="file" name="fphoto" id="fphoto" size="30">
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="gender">Gender <span>*</span></label></td>
              <td>
              <input type="radio" name="gender" value="male" <?php if ($row['gender']=="male"){
          echo "checked='checked'";
        }
          ?>size="17">Male
           <input type="radio" name="gender" value="female" <?php if ($row['gender']=="female"){
          echo "checked='checked'";
        }
          ?> size="17">Female
        </tr>
            <tr height="50">
              <td><label for="nrc">National Registration or Passport No. <span>*</span></label></td>
              <td><input type="text" name="membernrc" id="name" value="<?php echo $row['nrc']; ?>" size="30" required></td>
            </tr>
          <tr height="50">
              <td><label for="dob">Date of birth/ (Visa for Monks) <span>*</span></label></td>
              <td><input type="text" name="dob" id="dob" value="<?php echo $row['dob']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="pob">Place of birth  <span>*</span></label></td>
              <td><input type="text" name="pob" id="pob" value="<?php echo $row['pob']; ?>" size="30" required></td>
            </tr>
           <tr height="50" valign="middle">
              <td><label for="fathername">Father’s name  <span>*</span></label></td>
              <td><input type="text" name="fathername" id="fathername" value="<?php echo $row['fathername']; ?>" size="30" required></td>
            </tr>
            <?php
              $stquery="SELECT Country FROM students WHERE StudentID='$member'";
              $stcount = $itbmu->query($stquery)or die($itbmu->error);
              $row1 = $stcount->fetch_assoc();
            ?>
            <tr height="50" valign="middle">
              <td><label for="country">Country  <span>*</span></label></td>
              <td>
                <select name="country" id="country" style="width: 70%; padding: 8px;">
                  <option value="<?php echo $row1['Country']; ?>"><?php echo $row1['Country']; ?></option>
                  <option value="0">Please Choose Your Country</option>
                  <option value="Aaland Islands">Aaland Islands</option>
                  <option value="Afghanistan">Afghanistan</option>
                  <option value="Albania">Albania</option>
                  <option value="Algeria">Algeria</option>
                  <option value="American Samoa">American Samoa</option>
                  <option value="Andorra">Andorra</option>
                  <option value="Angola">Angola</option>
                  <option value="Anguilla">Anguilla</option>
                  <option value="Antarctica">Antarctica</option>
                  <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                  <option value="Argentina">Argentina</option>
                  <option value="Armenia">Armenia</option>
                  <option value="Aruba">Aruba</option>
                  <option value="Australia">Australia</option>
                  <option value="Austria">Austria</option>
                  <option value="Azerbaijan">Azerbaijan</option>
                  <option value="Bahamas">Bahamas</option>
                  <option value="Bahrain">Bahrain</option>
                  <option value="Bangladesh">Bangladesh</option>
                  <option value="Barbados">Barbados</option>
                  <option value="Belarus">Belarus</option>
                  <option value="Belgium">Belgium</option>
                  <option value="Belize">Belize</option>
                  <option value="Benin">Benin</option>
                  <option value="Bermuda">Bermuda</option>
                  <option value="Bhutan">Bhutan</option>
                  <option value="Bolivia">Bolivia</option>
                  <option value="Bosnia and Herzegowina">Bosnia and Herzegowina</option>
                  <option value="Botswana">Botswana</option>
                  <option value="Bouvet Island">Bouvet Island</option>
                  <option value="Brazil">Brazil</option>
                  <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                  <option value="Brunei Darussalam">Brunei Darussalam</option>
                  <option value="Bulgaria">Bulgaria</option>
                  <option value="Burkina Faso">Burkina Faso</option>
                  <option value="Burundi">Burundi</option>
                  <option value="Cambodia">Cambodia</option>
                  <option value="Cameroon">Cameroon</option>
                  <option value="Canada">Canada</option>
                  <option value="Cape Verde">Cape Verde</option>
                  <option value="Cayman Islands">Cayman Islands</option>
                  <option value="Central African Republic">Central African Republic</option>
                  <option value="Chad">Chad</option>
                  <option value="Chile">Chile</option>
                  <option value="China">China</option>
                  <option value="Christmas Island">Christmas Island</option>
                  <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                  <option value="Colombia">Colombia</option>
                  <option value="Comoros">Comoros</option>
                  <option value="Congo">Congo</option>
                  <option value="Cook Islands">Cook Islands</option>
                  <option value="Costa Rica">Costa Rica</option>
                  <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                  <option value="Croatia">Croatia</option>
                  <option value="Cuba">Cuba</option>
                  <option value="Cyprus">Cyprus</option>
                  <option value="Czech Republic">Czech Republic</option>
                  <option value="Denmark">Denmark</option>
                  <option value="Djibouti">Djibouti</option>
                  <option value="Dominica">Dominica</option>
                  <option value="Dominican Republic">Dominican Republic</option>
                  <option value="East Timor">East Timor</option>
                  <option value="Ecuador">Ecuador</option>
                  <option value="Egypt">Egypt</option>
                  <option value="El Salvador">El Salvador</option>
                  <option value="Equatorial Guinea">Equatorial Guinea</option>
                  <option value="Eritrea">Eritrea</option>
                  <option value="Estonia">Estonia</option>
                  <option value="Ethiopia">Ethiopia</option>
                  <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                  <option value="Faroe Islands">Faroe Islands</option>
                  <option value="Fiji">Fiji</option>
                  <option value="Finland">Finland</option>
                  <option value="France">France</option>
                  <option value="France, Metropolitan">France, Metropolitan</option>
                  <option value="French Guiana">French Guiana</option>
                  <option value="French Polynesia">French Polynesia</option>
                  <option value="French Southern Territories">French Southern Territories</option>
                  <option value="Gabon">Gabon</option>
                  <option value="Gambia">Gambia</option>
                  <option value="Georgia">Georgia</option>
                  <option value="Germany">Germany</option>
                  <option value="Ghana">Ghana</option>
                  <option value="Gibraltar">Gibraltar</option>
                  <option value="Greece">Greece</option>
                  <option value="Greenland">Greenland</option>
                  <option value="Grenada">Grenada</option>
                  <option value="Guadeloupe">Guadeloupe</option>
                  <option value="Guam">Guam</option>
                  <option value="Guatemala">Guatemala</option>
                  <option value="Guinea">Guinea</option>
                  <option value="Guinea-bissau">Guinea-bissau</option>
                  <option value="Guyana">Guyana</option>
                  <option value="Haiti">Haiti</option>
                  <option value="Heard and Mc Donald Islands">Heard and Mc Donald Islands</option>
                  <option value="Honduras">Honduras</option>
                  <option value="Hong Kong">Hong Kong</option>
                  <option value="Hungary">Hungary</option>
                  <option value="Iceland">Iceland</option>
                  <option value="India">India</option>
                  <option value="Indonesia">Indonesia</option>
                  <option value="Iran (Islamic Republic of)">Iran (Islamic Republic of)</option>
                  <option value="Iraq">Iraq</option>
                  <option value="Ireland">Ireland</option>
                  <option value="Israel">Israel</option>
                  <option value="Italy">Italy</option>
                  <option value="Jamaica">Jamaica</option>
                  <option value="Japan">Japan</option>
                  <option value="Jordan">Jordan</option>
                  <option value="Kazakhstan">Kazakhstan</option>
                  <option value="Kenya">Kenya</option>
                  <option value="Kiribati">Kiribati</option>
                  <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                  <option value="Korea, Republic of">Korea, Republic of</option>
                  <option value="Kuwait">Kuwait</option>
                  <option value="Kyrgyzstan">Kyrgyzstan</option>
                  <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                  <option value="Latvia">Latvia</option>
                  <option value="Lebanon">Lebanon</option>
                  <option value="Lesotho">Lesotho</option>
                  <option value=">Liberia">Liberia</option>
                  <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                  <option value="Liechtenstein">Liechtenstein</option>
                  <option value="Lithuania">Lithuania</option>
                  <option value="Luxembourg">Luxembourg</option>
                  <option value="Macau">Macau</option>
                  <option value="Macedonia">Macedonia, The Former Yugoslav Republic of</option>
                  <option value="Madagascar">Madagascar</option>
                  <option value="Malawi">Malawi</option>
                  <option value="Malaysia">Malaysia</option>
                  <option value="Maldives">Maldives</option>
                  <option value="Mali">Mali</option>
                  <option value="Malta">Malta</option>
                  <option value="Marshall Islands">Marshall Islands</option>
                  <option value="Martinique">Martinique</option>
                  <option value="Mauritania">Mauritania</option>
                  <option value="Mauritius">Mauritius</option>
                  <option value="Mayotte">Mayotte</option>
                  <option value="Mexico">Mexico</option>
                  <option value="Micronesia">Micronesia, Federated States of</option>
                  <option value="Moldova">Moldova, Republic of</option>
                  <option value="Monaco">Monaco</option>
                  <option value="Mongolia">Mongolia</option>
                  <option value="Montserrat">Montserrat</option>
                  <option value="Morocco">Morocco</option>
                  <option value="Mozambique">Mozambique</option>
                  <option value="Myanmar">Myanmar</option>
                  <option value="Namibia">Namibia</option>
                  <option value="Nauru">Nauru</option>
                  <option value="Nepal">Nepal</option>
                  <option value="Netherlands">Netherlands</option>
                  <option value="Netherlands Antilles">Netherlands Antilles</option>
                  <option value="New Caledonia">New Caledonia</option>
                  <option value="New Zealand">New Zealand</option>
                  <option value="Nicaragua">Nicaragua</option>
                  <option value="Niger">Niger</option>
                  <option value="Nigeria">Nigeria</option>
                  <option value="Niue">Niue</option>
                  <option value="Norfolk Island">Norfolk Island</option>
                  <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                  <option value="Norway">Norway</option>
                  <option value="Oman">Oman</option>
                  <option value="Pakistan">Pakistan</option>
                  <option value="Palau">Palau</option>
                  <option value="Panama">Panama</option>
                  <option value="Papua New Guinea">Papua New Guinea</option>
                  <option value="Paraguay">Paraguay</option>
                  <option value="Peru">Peru</option>
                  <option value="Philippines">Philippines</option>
                  <option value="Pitcairn">Pitcairn</option>
                  <option value="Poland">Poland</option>
                  <option value="Portugal">Portugal</option>
                  <option value="Puerto Rico">Puerto Rico</option>
                  <option value="Qatar">Qatar</option>
                  <option value="Reunion">Reunion</option>
                  <option value="Romania">Romania</option>
                  <option value="Russian Federation">Russian Federation</option>
                  <option value="Rwanda">Rwanda</option>
                  <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                  <option value="Saint Lucia">Saint Lucia</option>
                  <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                  <option value="Samoa">Samoa</option>
                  <option value="San Marino">San Marino</option>
                  <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                  <option value="Saudi Arabia">Saudi Arabia</option>
                  <option value="Senega">Senegal</option>
                  <option value="Seychelles">Seychelles</option>
                  <option value="Sierra Leone">Sierra Leone</option>
                  <option value="Singapore">Singapore</option>
                  <option value="Slovakia">Slovakia (Slovak Republic)</option>
                  <option value="Slovenia">Slovenia</option>
                  <option value="Solomon Islands">Solomon Islands</option>
                  <option value="Somalia">Somalia</option>
                  <option value="South Africa">South Africa</option>
                  <option value="Georgia">South Georgia and the South Sandwich Islands</option>
                  <option value="Spain">Spain</option>
                  <option value="Sri Lanka">Sri Lanka</option>
                  <option value="St. Helena">St. Helena</option>
                  <option value="St. Pierre and Miquelon">St. Pierre and Miquelon</option>
                  <option value="Sudan">Sudan</option>
                  <option value="Suriname">Suriname</option>
                  <option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                  <option value="Swaziland">Swaziland</option>
                  <option value="Sweden">Sweden</option>
                  <option value="Switzerland">Switzerland</option>
                  <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                  <option value="Taiwan">Taiwan</option>
                  <option value="Tajikistan">Tajikistan</option>
                  <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                  <option value="Thailand">Thailand</option>
                  <option value="Togo">Togo</option>
                  <option value="Tokelau">Tokelau</option>
                  <option value="Tonga">Tonga</option>
                  <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                  <option value="Tunisia">Tunisia</option>
                  <option value="Turkey">Turkey</option>
                  <option value="Turkmenistan">Turkmenistan</option>
                  <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                  <option value="Tuvalu">Tuvalu</option>
                  <option value="Uganda">Uganda</option>
                  <option value="Ukraine">Ukraine</option>
                  <option value="United Arab Emirates">United Arab Emirates</option>
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="United States">United States</option>
                  <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                  <option value="Uruguay">Uruguay</option>
                  <option value="Uzbekistan">Uzbekistan</option>
                  <option value="Vanuatu">Vanuatu</option>
                  <option value="Vatican City State (Holy See)">Vatican City State (Holy See)</option>
                  <option value="Venezuela">Venezuela</option>
                  <option value="Viet Nam">Viet Nam</option>
                  <option value="Virgin Islands (British)">Virgin Islands (British)</option>
                  <option value="irgin Islands (U.S.)">Virgin Islands (U.S.)</option>
                  <option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                  <option value="Western Sahara">Western Sahara</option>
                  <option value="Yemen">Yemen</option>
                  <option value="Yugoslavia">Yugoslavia</option>
                  <option value="Zaire">Zaire</option>
                  <option value="Zambia">Zambia</option>
                  <option value="Zimbabwe">Zimbabwe</option>
                </select>
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="citizenship">Citizenship <span>*</span></label></td>
              <td><input type="text" name="citizenship" id="citizenship" value="<?php echo $row['citizenship']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="maritalstatus">Marital Status <span>*</span></label></td>
              <td>
                <select name="maritalstatus" id="maritalstatus">
               <!--  <option value="">----- Select -----</option>
                <option value="Single">Single</option>
                <option value="Married">Married</option> -->
                <option value="Single"
                <?php if ($row['maritalstatus']=="Single"){
                  echo "selected='selected'";
                }
                  ?>
                >Single</option>
                <option value="Married"
                <?php if ($row['maritalstatus']=="Married"){
                  echo "selected='selected'";
                }
                  ?>
                >Married</option>
              </select>
                <!-- <input type="text" name="maritalstatus" id="maritalstatus" value="" size="30" required> -->
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="religion">Religion <span>*</span></label></td>
              <td><input type="text" name="religion" id="religion" value="<?php echo $row['religion']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="pha">Permanent Home Address <span>*</span></label></td>
              <td>
              <textarea name="pha" cols="60" rows="5"><?php echo $row['pha']; ?></textarea>
            </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="fax">Fax. E-mail, Tel. <span>*</span></label></td>
              <td><input type="text" name="fax" id="fax" value="<?php echo $row['fax']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="postaladdress">Postal Address <span>*</span></label></td>
              <td>
                <div id="sample">
                  <script type="text/javascript" src="richtext/nicEdit.js"></script>
                  <script type="text/javascript">
                    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
                  </script>
                  <textarea name="postaladdress" id="postaladdress" style="width: 500px; height: 100px;"><?php echo $row['postaladdress']; ?></textarea>
                </div>
              <!-- <textarea name="postaladdress" cols="" rows="5"><?php echo $row['postaladdress']; ?></textarea> -->
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="aqy">Academic qualification & Year <span>*</span></label></td>
              <td><input type="text" name="aqy" id="aqy" value="<?php echo $row['aqy']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="language">Language (Level & proficiency) <span>*</span></label></td>
              <td><input type="text" name="language" id="language" value="<?php echo $row['language']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="presentemployment">Present employment <span>*</span></label></td>
              <td><input type="text" name="presentemployment" id="presentemployment" value="<?php echo $row['presentemployment']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="diploma">Dip/B.A.(A)/B.A.(B) M.A/Ph.D & Academic year <span>*</span></label></td>
              <td><input type="text" name="diploma" id="diploma" value="<?php echo $row['diploma']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="status">Status <span>*</span></label></td>
              <td>
                 <select name="status" id="status">
                  <option value="Monk"
                  <?php if ($row['status']=="Monk"){
                    echo "selected='selected'";
                  }
                    ?>
                  >Monk</option>
                  <option value="Gent"
                  <?php if ($row['status']=="Gent"){
                    echo "selected='selected'";
                  }
                    ?>
                  >Gent</option>
                  <option value="Nun"
                  <?php if ($row['status']=="Nun"){
                    echo "selected='selected'";
                  }
                    ?>
                  >Nun</option>
                  <option value="Lady"
                  <?php if ($row['status']=="Lady"){
                    echo "selected='selected'";
                  }
                    ?>
                  >Lady</option>
                </select>
              </td>
            </tr>



            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="memberupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>

        </form>
 <?php }  ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
