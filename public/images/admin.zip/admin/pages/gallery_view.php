<?php

//header('Content-type: image/jpeg');
//readfile('/home4/kmdshopping/DataImages/uploadphoto/tests.jpg_2016-10-03-05-53-41_57f1f2659de6b.jpg');

    $file = basename(urldecode($_GET['file']));
	
    $fileDir = '/home5/itbmuorg/Data/Gallery/';

    if (file_exists($fileDir . $file))
    {
        // Note: You should probably do some more checks 
        // on the filetype, size, etc.
        $contents = file_get_contents($fileDir . $file);

        // Note: You should probably implement some kind 
        // of check on filetype
        header('Content-type: image/jpg');
        echo $contents;
    }

?>