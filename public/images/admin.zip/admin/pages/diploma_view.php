<?php
  $folder = realpath('/home5/itbmuorg/Data/Exam/');
  $file = realpath($folder.'/'.$_GET['file']);
  header(sprintf("Content-type: %s;",getMimeType($file)));
  readfile($file);
  exit;

   function getMimeType ( $filename ) {
    //MIME MAP
$mime_extension_map = array(
    'pdf'           => 'application/pdf',
    'zip'           => 'application/zip'
);
    //Get Extension

    $ext = strtolower(substr($filename,strrpos($filename,'.') + 1));
    if(empty($ext))
      return 'application/octet-stream';
    elseif(isset($mime_extension_map[$ext]))
      return $mime_extension_map[$ext];
    return 'x-extension/' . $ext;
  }
  
?>  
  
  