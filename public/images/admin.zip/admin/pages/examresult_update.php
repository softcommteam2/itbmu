<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;                  
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function checknull()
{
  if(document.getElementById("rollno").value=="")
  {
    window.alert("Please enter Roll No");
    document.getElementById("rollno").focus();
    return false;
  }
  else if(document.getElementById("name").value=="")
  {
    window.alert("Please enter Name");
    document.getElementById("name").focus();
    return false;
  }
  else if(document.getElementById("eyear").value=="")
  {
    window.alert("Please enter Year");
    document.getElementById("eyear").focus();
    return false;
  }
  else
  {
    return true;
  }
}
function setfocus()
{
  document.form.rollno.focus();
}
</script>
</head>
<body id="top"  onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Exam Result  Update Form</h3><br>
      <p class="nospace">
      <?php
        $exam=$_GET['del'];
        $query="SELECT * FROM tbl_examresult WHERE id='$exam'";
				$count = $itbmu->query($query)or die($itbmu->error);
				while ($row = $count->fetch_assoc()) {
          $courseyear=$row['courseyear'];
          $resultfile=$row['resultfile'];
          $resultdate=$row['resultdate'];
      ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="coursename">Exam Type <span>*</span></label></td>
              <td>
                <!-- <input type="text" name="coursename" id="coursename" value="<?php echo $row['coursename'];?>" size="30" required> -->
                 <select name="examtype" id="examtype">
                  <option value=""
                    <?php if ($row['examtype']==""){
                      echo "selected='selected'"; 
                    }
                      ?>
                            ></option>
                  <option value="Diploma course"
                    <?php if ($row['examtype']=="Diploma course"){
                      echo "selected='selected'"; 
                    }
                      ?>
                            >Diploma course</option>
                  <option value="Graduate degree course"
                    <?php if ($row['examtype']=="Graduate degree course"){
                      echo "selected='selected'"; 
                    }
                      ?>
                  >Graduate degree course</option>
                  <option value="M.A Post graduate course"
                  <?php if ($row['examtype']=="M.A Post graduate course"){
                      echo "selected='selected'"; 
                    }
                      ?>
                  >M.A Post graduate course</option>
                  <option value="Ph.D Post graduate course"
                    <?php if ($row['examtype']=="Ph.D Post graduate course"){
                      echo "selected='selected'"; 
                    }
                      ?>
                  >Ph.D Post graduate course</option>
                </select>
              </td>
            </tr>

            <tr height="50" valign="middle">
              <td><label for="coursename">Course Name <span>*</span></label></td>
              <td>
              <!-- <input type="text" name="coursename" id="coursename" value="<?php echo $row['coursename'];?>" size="30" required> -->
                <select name="coursename" id="coursename">
                  <option value="<?php echo $row['coursename'];?>"><?php echo $row['coursename'];?></option>
                  <?php
                    $res = $itbmu->query("SELECT coursename FROM tbl_coursetimetable");
                    while($row=$res->fetch_array())
                    {
                      $coursename=$row['coursename'];
                  ?>
                  <option value="<?php echo $coursename; ?>"><?php echo $coursename; ?></option>
                  <?php
                    }
                  ?>
                </select>
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="courseyear">Course Year <span>*</span></label></td>
              <td><input type="text" name="courseyear" id="courseyear" value="<?php echo $courseyear;?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="resultfile">Result File <span>*</span></label></td>
              <td>
              <input type="text" name="resultfile" id="resultfile" value="<?php echo $resultfile;?>" size="30" readonly>
              <br> <input type="file" name="fresultfile">
            </td>
            </tr>
            <tr height="50">
              <td><label for="resultdate">Result Date <span>*</span></label></td>
              <td><input type="date" name="resultdate" id="resultdate" value="<?php echo $resultdate; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="examupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
    <?php  } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>