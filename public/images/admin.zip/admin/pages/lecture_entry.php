<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/insert_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}

$_REQUEST['message']="";
$message=$_REQUEST['message'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavãda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function setfocus()
{
  document.form.lecname.focus();
}
</script>
</head>
<body id="top"  onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Lecture Entry Form</h3><br>
      
      <p class="nospace">
        <form name="form" action="#" method="post" enctype="multipart/form-data">
          <?php
								function msg($a){
									$msg = (!empty($_REQUEST[$a]) ? $_REQUEST[$a] : "");
									return $msg;
								}
								//echo "<font color=\"green\">".$_REQUEST['msg']."</font>";
								//echo "<font color=\"green\">".msg('msg')."</font>";
								echo "<font color=\"red\">".msg('msg_duplicate')."</font>";
								?>
          <table>
            <tr height="50" valign="middle">
              <td><label for="lecname">Name </label></td>
              <td><input type="text" name="lecname" id="lecname" size="30" required><?php echo @$msg; ?></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="lecemail">Email <span>*</span></label></td>
              <td><input type="email" name="lecemail" id="lecemail" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="lecaddress">Address <span>*</span></label></td>
              <td><textarea name="lecaddress" cols="32" rows="3" required></textarea></td>
            </tr>
            <tr height="50">
              <td><label for="lecphone">Phone <span>*</span></label></td>
              <td><input type="text" name="lecphone" id="lecphone" size="30" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="lecsave" value="Save"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>