<?php
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$itbmu = new mysqli("localhost", "itbmuorg_user", "itbmuorg_user@123", "itbmuorg_db");
function showDate($date,$format='Y-m-d') {
   if(empty($date)) return ' ';
   return date($format,strtotime($date));
 }

function showDate1($date1,$format='Y-m-d') {
      if(empty($date1)) return ' ';
      return date($format,strtotime($date1));
}
if (isset($_POST['btn_export_main'])) {

  $tdate = showDate($_POST['tdate'],'Y-m-d');
  $tdate1 = showDate1($_POST['tdate1'],'Y-m-d');

  $tables = array(
                  "SELECT * FROM students WHERE DATE(create_date) BETWEEN '$tdate' AND '$tdate1'" =>
                  'INSERT INTO students(StudentName, Country, Class, create_date) VALUES(',
                  // "SELECT * FROM students WHERE DATE(create_date) BETWEEN '$tdate' AND '$tdate1'" =>
                  // 'INSERT INTO students(StudentID,StudentName, Country, Class, create_date) VALUES(',
                  );
  $return = '';
  foreach($tables as $key => $value)
  {
  $result = mysqli_query($itbmu, $key);
  $num_fields = mysqli_num_fields($result);
  $num_rows = mysqli_num_rows($result);
  $counter = 1;
  for ($i = 1; $i < $num_fields; $i++)
  {   //Over rows
    while($row = mysqli_fetch_row($result))
    {
        if($counter == 1){
            $return.= $value;
        } else{
            $return.= '(';
        }
        //Over fields
        for($j=1; $j<$num_fields; $j++)
        {
              $row[$j] = addslashes($row[$j]);
              $row[$j] = str_replace("\n","\\n",$row[$j]);
              if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
              if ($j<($num_fields-1)) { $return.= ','; }
        }
        if($num_rows == $counter){
            $return.= ");\n";
        } else{
            $return.= "),\n";
        }
        ++$counter;
      }
    }
    $return.='';
  }
  $tables_update = array(
                "SELECT * FROM students WHERE DATE(create_date) BETWEEN '$tdate' AND '$tdate1'" => 'students'
                );
  $return .= '';
  foreach($tables_update as $key => $value)
  {
      $result = mysqli_query($itbmu, $key);
      $num_fields = mysqli_num_fields($result);
      $num_rows = mysqli_num_rows($result);
      for ($i = 1; $i < $num_fields; $i++)
      {   //Over rows
          while($row = mysqli_fetch_row($result))
          {
            //Over fields
            if ($value == 'students') {
            $return .= 'UPDATE students SET ';
            $return .= 'StudentName='; if (isset($row[1])) { $return.= '"'.$row[1].'", ' ; } else { $return.= '"", ' ; }
            $return .= 'Country='; if (isset($row[2])) { $return.= '"'.$row[2].'", ' ; } else { $return.= '"", ' ; }
            $return .= 'Class='; if (isset($row[3])) { $return.= '"'.$row[3].'", ' ; } else { $return.= '"", ' ; }
            $return .= 'create_date='; if (isset($row[4])) { $return.= '"'.$row[4].'" ' ; } else { $return.= '"" ' ; }
            $return .= "WHERE StudentID='$row[0]';\n";
            }
          }
      }
      $return.="\n\n\n";
    }
    $fileName = 'db-backup-for-main'.time().'.sql';
    $handle = fopen($fileName,'w+');
    fwrite($handle,$return);
    // if(fclose($handle)){
    //   //echo "Done, the file name is: ".$fileName;
    //   exit;
    //
    // }
    // $resquery="INSERT INTO  tbl_studentexport (filename,exportdate) VALUES ('$fileName', NOW())";
    //$resquery = $itbmu->query("INSERT INTO  tbl_studentexport (filename,exportdate) VALUES ('$fileName', NOW())");

	$stmt = $itbmu->stmt_init();
	$stmt->prepare("INSERT INTO tbl_studentexport (filename,exportdate) VALUES (?,NOW())");
	$stmt->bind_param("s", $fileName);
	$stmt->execute() or die($stmt->error);
	$stmt->close();
			
    //$count = $resquery->num_rows;
  // while($row=$resquery->fetch_array())
  // {
  //   $user=$row['user'];
  //   $usertype=$row['usertype'];
  //   $createdate=$row['createdate'];
  //   $lastindate=$row['lastindate'];
  // }
    echo '<script language="javascript">';
    echo 'alert("Export Successfully")';
    echo '</script>';
    print "<script language=\"JavaScript\">window.location.href=\"index.php?page=export_studentlist\</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Export Student List</h3><br>
      <p class="nospace">
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="username">Export - Date From  :<span>*</span></label></td>
              <td><input type="text" id="tdate" data-format="DD-MM-YYYY" data-template="D MMM YYYY" name="tdate" placeholder="dd-mm-yyyy" class="textbox" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="username">Date To :<span>*</span></label></td>
              <td><input type="text" id="tdate1" data-format="DD-MM-YYYY" data-template="D MMM YYYY" name="tdate1" placeholder="dd-mm-yyyy" class="textbox" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="btn_export_main" value="Export"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>

        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>
