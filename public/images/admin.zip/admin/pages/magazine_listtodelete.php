<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
		echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<script>
$('document').ready(function()
{
$(".select-all").click(function ()
{
$('.chk-box').attr('checked', this.checked)
});

$(".chk-box").click(function()
{
if($(".chk-box").length == $(".chk-box:checked").length)
{
$(".select-all").attr("checked", "checked");
}
else
{
$(".select-all").removeAttr("checked");
}
});
});

// dynamically redirects to specified page




function delete_records()
{
document.frm.action = "index.php?page=magazine_delete";
document.frm.submit();
}
</script>
<body id="top">
<?php
      // function trim_text4($text, $count){
      // $trimed="";
      // $text = str_replace("  ", " ", $text);
      // $string = explode(" ", $text);
      // for ($wordCounter = 0; $wordCounter <= $count;$wordCounter++ ){
      // @$trimed .= @$string[@$wordCounter];
      // if ( $wordCounter < $count ){ $trimed .= " "; }
      // else { $trimed .= "..."; }
      // }
      // $trimed = trim($trimed);
      // return $trimed;
      // }
    ?>
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
      <h1>Magazine Delete List</h1>
      <form method="post"  name="frm" action="<?php $_SERVER['SCRIPT_NAME'];?>?page=magazine_listtodelete&Pg=a">
      <table id="example"  cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
              <th></th>
              <th align="center">Title</th>
              <th align="center">Cover Photo</th>
              <th align="center">Volume No</th>
              <th align="center">Published Year (Myan)</th>
              <th align="center">Published Year (Eng)</th>
              <th align="center">Content</th>
              <th align="center">Article</th>
            </tr>
        </thead>
        
       
        <tbody>
          <?php
                        $stmt = $itbmu->stmt_init();
   			$stmt->prepare("SELECT id,title,coverphoto,volumeno,mpublishedyear,epublishedyear,content,article FROM tbl_magazine");
   			$stmt->execute() or die($stmt->error);
   			$stmt->store_result();
   			$stmt->bind_result($magid,$magtitle,$magphoto,$volumeno,$mpublishedyear,$epublishedyear,$magcon,$magart);
   			while($stmt->fetch())
				{
                                    ?>
            <tr>
               <td  width="35%" align="center"><input type="checkbox" name="chk[]" class="chk-box" value="<?php echo $magid; ?>" /></td>
              <td><?php echo $magtitle;?></td>
              <td><img src="index.php?page=magazine_view&file=<?php echo $magphoto; ?>" style="width:100px; height:100px"></td>
              <td><?php echo $volumeno;?></td>
              <td><?php echo $mpublishedyear;?></td>
              <td><?php echo $epublishedyear;?></td>
              <td><?php echo $magcon;?></td>
              <?php //echo $magart;?>
              <td><a href="index.php?page=secure_magazine&file=<?php echo $magart;?>" target="_blank"><?php echo $magart;?></a></td>
            </tr>
            <?php } ?>
        </tbody>
        
    </table>
        <label id="actions">
            <button type="submit" onClick="delete_records();" alt="delete" class="btn">delete </button>
            </label>
    </form> 
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": false,
 "scrollY":        "200px",
 "scrollX": true,
 "scrollCollapse": true
 
        
        
  });
 
	
} );
</script>
</html>
