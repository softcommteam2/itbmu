<?php
require_once('connection/connection.php');

$message = "";
if (isset($_POST['btn_login']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];
  $userlevel = $_POST['userlevel'];

  /* create a prepared statement */
  $stmt = $itbmu->stmt_init();
  $stmt->prepare("SELECT uid FROM tbl_user WHERE user=? AND password=? AND usertype=?");
  /* bind parameters for markers */
  $stmt->bind_param("sss", $username, $password, $userlevel);
  /* execute query */
  $stmt->execute() or die($stmt->error);
  /* store result */
  $stmt->store_result();
  $numrow = $stmt->num_rows();

  if($numrow>0){
    /* bind result variables */
    $stmt->bind_result($uid);
    /* fetch value */
    $stmt->fetch();

    $_SESSION['uid'] = $uid;
    $_SESSION['userlevel'] = $userlevel;

    $stmt->close();

    $sql = "UPDATE tbl_user SET lastindate = NOW() WHERE uid = '$uid'";
    $result = $itbmu->query($sql)or die($itbmu->error);
    print "<script language=\"JavaScript\">window.location.href=\"index.php?page=main\";</script>";
  }
  else {
    $_SESSION['uid']="";
    $_SESSION['userlevel']="";
    $message = "<div class=\"alert alert-danger fade in\">
               <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
               <strong>Warning!</strong> Sorry, Your User Name and Password are not matched!
               </div>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<style>
video {
    width: 100%;
    height: auto;
}
audio {
    width: 100%;
    height: auto;
}
</style>
</head>
<script type="text/javascript">
function checknull()
{
if (document.getElementById("username").value == "")
  {
    window.alert("Please Enter Login Name");
    document.getElementById("username").focus();
    return false;

  }

  if(document.getElementById("password").value == "")
  {
    window.alert("Please Enter Password");
    document.getElementById("password").focus();
    return false;
  }

  return true;
}
function setfocus()
{
  document.form.username.focus();
}
</script>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><img src="../images/demo/adminlogo.png"><!-- <a href="#">Tharavāda Buddhist Missionary University</a> --></h1>
    </div>
    
    <!-- ################################################################################################ -->
  </header>
</div>
<hr>
<?php //require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace" align="center">Log In</h3><br>
        <form action="" method="post">
          <div align="center">
            <label for="username">User Name <span>*</span></label>
            <input type="text" name="username" id="username"  size="22" autocomplete="off" required>
          </div>
          <div align="center">
            <label for="password">Password <span>*</span></label>
            <input type="password" name="password" id="password"  size="22" autocomplete="off" required>
          </div>
          <div align="center">
            <label for="userlevel">User Level <span>*</span></label>
            <select name="userlevel" id="userlevel" style="margin-bottom:40px;" autocomplete="off">
              <option value="">----- Select -----</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
         
          <div align="center">
            <input type="submit" name="btn_login" id="btn_login" value="Login">
            &nbsp;
            <input type="reset" name="reset" value="Cancel">
          </div>
          <br><br><br><br><br><br><br><br><br>
        </form>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->

  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>