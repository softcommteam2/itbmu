<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
		echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
      <h1>Member List</h1>
     
      <table id="example"  cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
             <th align="center" width="15%">Name</th>
              <th align="center">Gender</th>
              <th align="center">Class</th>
              <th align="center">Country</th>
              <th align="center">Fax. E-mail, Tel.</th>
              <th align="center" width="12%">AcademicYear</th>
              <th align="center">Qualification</th>
              <th align="center">Photo</th>
            </tr>
        </thead>
        
       
        <tbody>
          <?php
                        $stmt = $itbmu->stmt_init();
   			$stmt->prepare("SELECT id,name,gender,religion,pha,fax,aqy,diploma,photo FROM tbl_itbmumember");
   			$stmt->execute() or die($stmt->error);
   			$stmt->store_result();
   			$stmt->bind_result($member,$name,$gender,$religion,$pha,$fax,$aqy,$diploma,$photo);
   			while($stmt->fetch())
				{
                                    ?>
            <tr>
              <td><?php echo $name;?></td>
              <td><?php echo $gender;?></td>
              <!-- <td><?php echo $nrc;?></td> -->
              <td><?php
                $stquery="SELECT Class FROM students WHERE StudentID='$member'";
                $stcount = $itbmu->query($stquery)or die($itbmu->error);
                $row1 = $stcount->fetch_assoc();
                $class=$row1['Class'];
              echo $class;
              ?></td>
              <td><?php
                $stquery1="SELECT Country FROM students WHERE StudentID='$member'";
                $stcount1 = $itbmu->query($stquery1)or die($itbmu->error);
                $row11 = $stcount1->fetch_assoc();
                $country=$row11['Country'];
              echo $country;
              ?></td>
              <td><?php echo $fax;?></td>
             <!--  <td><?php echo $postaladdress?></td> -->
              <td align="center"><?php echo $aqy?></td>
              <td><?php echo $diploma?></td>
              <td><img src="index.php?page=member_view&file=<?php echo $photo?>" style="width:100px; height:80px;"><br><?php echo $photo?></td>
            </tr>
            <?php } ?>
        </tbody>
        
    </table>
        
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": true,
 "scrollY":        "200px",
 "scrollCollapse": true,

 
        
        
  });
 
	
} );
</script>
</html>
