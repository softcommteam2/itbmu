<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/insert_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Faculty Entry Form</h3><br>
      <p class="nospace">
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="facultyname">Faculty Name <span>*</span></label></td>
              <td><input type="text" name="facultyname" id="facultyname" value="" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="department">Department <span>*</span></label></td>
              <td><input type="text" name="department" id="department" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="description">Description <span>*</span></label></td>
              <td>
              <div id="sample">
                <script type="text/javascript" src="richtext/nicEdit.js"></script>
                <script type="text/javascript">
                  bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
                </script>
              <textarea name="description" id="description" style="width: 500px; height: 100px;"></textarea>
              </div>
              <!-- <textarea name="description" id="description" rows="8" cols="50" required></textarea> -->
             <!--  <input type="text" name="description" id="description" size="30" required> -->
              </td>
            </tr>
            <tr height="50">
              <td><label for="photo1">Photo 1 <span>*</span></label></td>
              <td><input type="file" name="photo1" id="photo1"  size="30" required></td>
            </tr>
             <tr height="50">
              <td><label for="photo2">Photo 2 </label></td>
              <td><input type="file" name="photo2" id="photo2"  size="30" ></td>
            </tr>
             <tr height="50">
              <td><label for="photo3">Photo 3</label></td>
              <td><input type="file" name="photo3" id="photo3"  size="30" ></td>
            </tr>
             <tr height="50">
              <td><label for="photo4">Photo 4 </label></td>
              <td><input type="file" name="photo4" id="photo4"  size="30" ></td>
            </tr>
             <tr height="50">
              <td><label for="photo5">Photo 5 </label></td>
              <td><input type="file" name="photo5" id="photo5"  size="30" ></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="save" value="Save"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>