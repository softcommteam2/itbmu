<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;                  
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Magazine Update Form</h3><br>
      <p class="nospace">
      <?php

 $magazine=$_GET['del'];

 $query="SELECT * FROM tbl_magazine WHERE id='$magazine'";
 //echo $query;
								$count = $itbmu->query($query)or die($itbmu->error);

								while ($row = $count->fetch_assoc()) {

									//echo $row['create_date'];


 ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td><label for="title">Title </label></td>
              <td><input type="text" name="title" id="title" value="<?php echo $row['title'] ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="coverphoto">Cover Photo <span>*</span></label></td>
              <td><input type="text" name="coverphoto" id="coverphoto" value="<?php echo $row['coverphoto']; ?>" size="30"  readonly="readonly"><br><img src="index.php?page=magazine_view&file=<?php echo $row['coverphoto']; ?>" style="width:100px; height:80px;"><br> <br> <input type="file" name="fcoverphoto" id="fcoverphoto"> </td>
            </tr>
            <tr height="50">
              <td><label for="author">Volume No. <span>*</span></label></td>
              <td><input type="text" name="volumeno" id="volumeno" value="<?php echo $row['volumeno']; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="publisher">Published Year (Myanmar) <span>*</span></label></td>
              <td><input type="text" name="mpublishedyear" id="mpublishedyear" value="<?php echo $row['mpublishedyear'];?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="releasedate">Published Year (English) <span>*</span></label></td>
              <td><input type="text" name="epublishedyear" id="epublishedyear" value="<?php echo $row['epublishedyear'];?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="content">Content <span>*</span></label></td>
              <td>
                <!-- <input type="text" name="content" id="content" value="<?php echo $row['content']; ?>" size="30" required> -->
                <div id="sample">
                  <script type="text/javascript" src="richtext/nicEdit.js"></script>
                  <script type="text/javascript">
                    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
                  </script>
                <textarea name="content" id="content" style="width: 650px; height: 100px;"><?php echo $row['content']; ?></textarea>
                </div>
              </td>
            </tr>
            <tr height="50">
              <td><label for="article">Article <span>*</span></label></td>
  <td><input type="text" name="article" id="article" value="<?php echo $row['article']; ?>" size="30"  readonly="readonly"><br><img src="index.php?page=secure_magazine&file=<?php echo $row['article']; ?>" style="width:100px; height:80px;"><br> <br> <input type="file" name="article"> </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="magupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
        <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>