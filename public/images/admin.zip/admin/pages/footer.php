<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">www.itbmu.org.mm</a></p>
    <p class="fl_right">Empowered By <a target="_blank" href="http://www.soft-comm.com/" title="Free Website Templates">SoftComm Technology ®</a></p>
    <!-- ################################################################################################ -->
  </div>
</div>