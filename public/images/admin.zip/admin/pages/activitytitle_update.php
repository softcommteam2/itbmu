<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Activity Title Update Form</h3><br>
      <p class="nospace">
      <?php
        $pgid=$_GET['del'];
       $stmt = $itbmu->stmt_init();
  $stmt->prepare("SELECT activitytitle  FROM tbl_activitytitle WHERE titleid=?");
  $stmt->bind_param("s", $pgid);
  $stmt->execute() or die($stmt->error);
  $stmt->store_result();
  $stmt->bind_result($activitytitle);
  while($stmt->fetch())
       {
      ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            
            <tr height="50" valign="middle">
              <td><label for="atitle">Activity Title  <span>*</span></label></td>
              <td><input type="text" name="atitle" id="atitle" value="<?php echo $activitytitle; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="atupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
        </form>
      <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>