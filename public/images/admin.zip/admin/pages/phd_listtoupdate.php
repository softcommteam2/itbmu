<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];

if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
      <h1>Ph.D Holder Update List</h1>
       <font size="4" color="green"><?php echo @$_REQUEST['msg']; ?></font>
     
      <table id="example"  cellspacing="0" width="100%" height="50%">
        <thead>
            <tr style="font-size:12px;">
               <th width="10%" align="center">Sr. No.</th>
              <th align="center">Roll No.</th>
              <th align="center">Name</th>
              <th align="center">Year</th>
              <th align="center">Country</th>
              <th align="center">Action</th>
            </tr>
        </thead>
        
       
        <tbody>
          <?php
                                        $stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT id,srno,rollno,name,phdyear,country FROM tbl_phd");
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		$stmt->bind_result($phdid,$srno,$rollno,$namephd,$phpyear,$country);
		while($stmt->fetch())
		{
                                            ?>
            <tr>
              <td align="right"><?php echo $srno;?></td>
              <td><?php echo $rollno;?></td>
              <td><?php echo $namephd;?></td>
              <td align="center"><?php echo $phpyear;?></td>
              <td align="center"><?php echo $country;?></td>
            <td><a href="index.php?page=phd_update&del=<?php echo $phdid; ?>">Update</a></td>
            </tr>
            <?php } ?>
        </tbody>
        
    </table>
        
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": false,
 "scrollY":        "200px",
        "scrollCollapse": true,
 
        
        
  });
 
	
} );
</script>
</html>