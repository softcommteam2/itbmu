<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
require_once("function/edit_process.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$_REQUEST['message']="";
$message=$_REQUEST['message'];
$sql = "SELECT srno FROM tbl_phd ORDER BY srno DESC LIMIT 1";
$result = $itbmu->query($sql)or die($itbmu->error);
$row = $result->fetch_assoc();
$sr_no = $row['srno'];
$srno = $sr_no +1;                  
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Multimedia Update Form</h3><br>
      <p class="nospace">
      <?php

 $multi=$_GET['del'];

 $query="SELECT * FROM tbl_multimedia WHERE id='$multi'";
 //echo $query;
								$count = $itbmu->query($query)or die($itbmu->error);

								while ($row = $count->fetch_assoc()) {

									//echo $row['create_date'];


 ?>
        <form action="#" method="post" enctype="multipart/form-data">
        <input type="hidden" name="fff" value="<?php echo $multi; ?>" >
          <table>
            <tr height="50" valign="middle">
              <td><label for="title">Title </label></td>
              <td><input type="text" name="multititle" id="title" value="<?php echo $row['title']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="presentername">Presenter Name <span>*</span></label></td>
              <td><input type="text" name="multipresentername" id="presentername" value="<?php echo $row['presentername']; ?>" size="30" required>
   </td> 

            </tr>
            <tr height="50">
              <td><label for="filetype" >File Type <span>*</span></label></td>
              <td><select name="multifiletype" id="filetype" >
                <option value="mp3" 
                <?php if ($row['filetype']=="mp3"){
					echo "selected='selected'";	
				}
					?>
                >*.mp3</option>
                <option value="mp4"
                <?php if ($row['filetype']=="mp4"){
					echo "selected='selected'";	
				}
					?>
                >*.mp4</option>
              </select></td>
            </tr>
            <tr height="50">
              <td><label for="mediafile">File (*.mp3/*.mp4) <span>*</span></label></td>
              <td>
           <img src="/home5/itbmuorg/Data/Multimedia/<?php echo $row['file']; ?>" style="width:100px; height:80px;"><br> <br> <input type="file" name="multiphoto">
              </td>
            </tr>
            <tr height="50">
              <td><label for="releasedate">Released Date <span>*</span></label></td>
              <td><input type="date" name="releasedate" id="myDate" value="<?php echo $row['releasedate'];?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="multiupdate" value="Update"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
        <?php } ?>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>