<?php
session_start();
?>
<?php
header("Content-type: application/vnd.excel");
header("Content-Disposition: attachment;Filename=subscription_mail_list.xls");
header("Expires: 0");
header("Cache-Control: must-revalidate,post-check=0,pre-check=0");
?>

<?php

$itbmu= new mysqli("localhost", "itbmuorg_user", "itbmuorg_user@123", "itbmuorg_db");

if ($itbmu->connect_error) {
    die("Connection Failed: ". $itbmu->connect_error);

}

$doc ="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
<tr border=\"0\"><th align=\"left\" border=\"0\" colspan=\"4\"><font color=\"#4f81bd\" size=\"+2\" face=\"Garamond\"><b>Subscribe Email List</b></font></th></tr>";



//echo $doc;
$Host = "localhost";
$User = "itbmuorg_user";
$Password = "itbmuorg_user@123";
$DBName = "itbmuorg_db";
$TableName = "tbl_subscribe";
$id=session_id();


$soinfo ="SELECT name,email,createdate FROM tbl_subscribe"; 


$soquery=$itbmu->query($soinfo)or die($itbmu->error);
 while ($sorow = $soquery->fetch_assoc())
 
 {		
		$name=$sorow['name'];
                $email=$sorow['email'];
                $createdate=$sorow['createdate'];
                if ($sorow !== "" ) { @$no++; }


$doc .="<tr>
      <td>$no</td>
      <td>$name</td>
      <td>$email</td>
      <td>$createdate</td>
    </tr>";




 }
$doc .="</table>";
echo "$doc";
?>
