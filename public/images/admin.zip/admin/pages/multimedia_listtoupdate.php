<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
//$uid = $_SESSION['uid'];
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}

?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
<title>Tharavãda Buddhist Missionary University</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear">
    <!-- main body -->
    <!-- ################################################################################################ -->
    
      <h1>Multimedia Update List</h1>
     
      <table id="example"  cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
                <th align="center">Title</th>
              <th align="center" width="20%">Presenter Name</th>
              <th align="center">File Type</th>
              <th align="center">File</th>
              <th align="center">Release Date</th>
              <th align="center">Action</th>
            </tr>
        </thead>
        
       
        <tbody>
          <?php
                $stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT id,title,presentername,filetype,file,releasedate FROM tbl_multimedia");
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		$stmt->bind_result($mulid,$title,$presentername,$filetype,$file,$releasedate);
		while($stmt->fetch())
		{
                                    ?>
            <tr>
              <td><?php echo $title;?></td>
              <td><?php echo $presentername;?></td>
              <td><?php echo $filetype;?></td>
              <?php if($filetype='mp3') { ?>
              <td><img src="index.php?page=view&file=<?php echo $file; ?>" style="width:50px; height:50;"> </td>
              <?php } else { ?>
              <td><img src="index.php?page=view_video&file=<?php echo $file; ?>" style="width:50px; height:50;"> </td>
              <?php } ?>
              <td><?php echo $releasedate;?></td>
              <td><a href="index.php?page=multimedia_update&del=<?php echo $mulid; ?>">Update</a></td>
            </tr>
            <?php } ?>
        </tbody>
        
    </table>
        
     
    
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.12.4.js" charset="utf-8"></script>
<script src="js/jquery.dataTables.min.js" charset="utf-8"></script>

 <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable({
   "bPaginate": true,
"bLengthChange": false,
"bFilter": true,
"bInfo": false,
"bAutoWidth": false,
 "scrollY":        "200px",
        "scrollCollapse": true,
 
        
        
  });
 
	
} );
</script>
</html>