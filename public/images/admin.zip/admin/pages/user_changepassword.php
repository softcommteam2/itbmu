<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$uid = $_SESSION['uid'];
// $_REQUEST['msg']="";
// $_REQUEST['msg1']="";
// $_REQUEST['$npw']="";
// $_REQUEST['$rpw']="";
if (isset($_REQUEST['save']))
{
	$username = $itbmu->real_escape_string((isset($_POST['username']) ? $_POST['username'] : ""));
	$currentpassword = $itbmu->real_escape_string((isset($_POST['currentpassword']) ? $_POST['currentpassword'] : ""));
	$newpassword = $itbmu->real_escape_string((isset($_POST['newpassword']) ? $_POST['newpassword'] : ""));
	$renewpassword = $itbmu->real_escape_string((isset($_POST['renewpassword']) ? $_POST['renewpassword'] : ""));
	$usertype = $itbmu->real_escape_string((isset($_POST['usertype']) ? $_POST['usertype'] : ""));

	$stmt = $itbmu->stmt_init();
	$stmt->prepare("SELECT password FROM tbl_user WHERE uid=?");
	$stmt->bind_param("s", $uid);
	$stmt->execute() or die($stmt->error);
	$stmt->store_result();
	$stmt->bind_result($currentpw);
	$stmt->fetch();
	$stmt->close();

	//echo "$cpw<br>";

	
	//echo "$cpw<br>";


		if($currentpassword!=$currentpw)
		{
			echo $msg="Current Password is not match existing password! Please type current password.";
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=user_changepassword&msg=$msg\";</script>";
		}
		else
		{
			$stmt = $itbmu->stmt_init();
		  	$stmt->prepare("UPDATE tbl_user SET user=?,password=?,usertype=? WHERE uid=?");
		  $stmt->bind_param("sssi", $username, $newpassword, $usertype, $uid);
		  $stmt->execute() or die($stmt->error);
		  $stmt->close();

			$msg1="User Update Successfully";
			print "<script language=\"JavaScript\">window.location.href=\"index.php?page=user_list&msg=$msg1\";</script>";
		}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript">
function checknull()
{
  if(document.getElementById("username").value=="")
  {
    window.alert("Please type User Name!");
    document.getElementById("username").focus();
    return false; 
  }
  else if(document.getElementById("currentpassword").value=="")
  {
    window.alert("Please type Current Password!");
    document.getElementById("currentpassword").focus();
    return false; 
  }

  else if(document.getElementById("newpassword").value=="")
  {
    window.alert("Please type New Password!");
    document.getElementById("newpassword").focus();
    return false; 
  }
  
  else if(document.getElementById("renewpassword").value=="")
  {
    window.alert("Please type (Reenter) Password!");
    document.getElementById("renewpassword").focus();
    return false; 
  }
  else if(document.getElementById("renewpassword").value!="")
  {
    var npw=document.getElementById("newpassword").value;
    var rpw=document.getElementById("renewpassword").value;
    if(npw!=rpw)
    {
    window.alert("These passwords don't match in New Password! Please type Reenter Password");
    document.getElementById("renewpassword").focus();
    return false; 
    }
    else
    {
      return true;
    }
    
  }
  
}
function setfocus()
{
  document.form.username.focus();  
}
</script>
</head>
<body id="top" onload="setfocus()">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="center btmspace-50"><br>
      <h3 class="font-x2 nospace">Change User Password Form</h3><br>
      <p class="nospace">
        <?php
          $res = $itbmu->query("SELECT * FROM tbl_user WHERE uid='$uid'");
          $count = $res->num_rows;
          $row=$res->fetch_array();
          $name=$row['user'];
          $usertype=$row['usertype'];
        ?>
        <form action="#" method="post" enctype="multipart/form-data">
          <table>
            <tr height="50" valign="middle">
              <td colspan="2" align="center">
                <?php
                  echo "<font color=\"green\">".@$_REQUEST['msg']."</font>";
                ?>
               
                <br><br>
              </td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="username">User Name <span>*</span></label></td>
              <td><input type="text" name="username" id="username" value="<?php echo $name; ?>" size="30" required ></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="currentpassword">Current Password <span>*</span></label></td>
              <td><input type="password" name="currentpassword" id="currentpassword" value="" size="30" required> <?php
                  echo "<font color=\"red\">".@$msg."</font>";
                ?></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="newpassword">New Password <span>*</span></label></td>
              <td><input type="password" name="newpassword" id="newpassword" value="<?php echo @$_REQUEST['newpassword']; ?>" size="30" required></td>
            </tr>
            <tr height="50" valign="middle">
              <td><label for="renewpassword">(Re-enter) New Password <span>*</span></label></td>
              <td><input type="password" name="renewpassword" id="renewpassword" value="<?php echo @$_REQUEST['renewpassword']; ?>" size="30" required></td>
            </tr>
            <tr height="50">
              <td><label for="usertype">User Type <span>*</span></label></td>
              <td>
                <select name="usertype" id="usertype">
                  <option value="Admin" 
                  <?php if ($usertype=="Admin"){
                      echo "selected='selected'"; 
                    }
                  ?>
                  >Admin</option>
                  <option value="User" 
                  <?php if ($usertype=="User"){
                    echo "selected='selected'"; 
                    }
                  ?>
                  >User</option>
                </select>
              </td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="submit" name="save" value="Save" onclick="return checknull()"></td>
            </tr>
            <tr height="50">
              <td>&nbsp;</td>
              <td><input type="reset" name="cancel" value="Cancel"></td>
            </tr>
          </table>
          
        </form>
      </p>
    </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>