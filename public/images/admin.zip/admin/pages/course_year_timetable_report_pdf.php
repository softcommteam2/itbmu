<?php
session_start();
require_once("../dompdf/dompdf_config.inc.php");
require_once("../connection/connection.php");
$idds = $_SESSION['id_array'];
$printdate=date('d-m-Y');

$message = '<h3 align="center"> Report for Course Year Timetable List</span>
<h6 align="right">Print Date :&nbsp;'. $printdate .'</h6>

<table width="100%" border="1" cellspacing="0">
<tr>
<th>No</th>
<th align="left">Course Name</th>
<th>Open Date</th>
<th>Open Time</th>
<th>Open Day</th>
</tr>';

foreach ($idds as $key => $value) {

	//$query2="SELECT * FROM tbl_order AS o, tbl_user AS u, tbl_fcentre AS f, tbl_order_detail AS d, tbl_book AS b WHERE u.user_id=o.user_id AND o.order_id=d.order_id AND f.fcentre_id=u.fcentre_id AND d.book_no=b.book_no AND o.order_id = '$value'";
	$query2="SELECT * FROM  tbl_coursetimetable WHERE id='$value'";
	$count = $itbmu->query($query2)or die($itbmu->error);
	while ($row = $count->fetch_assoc())
	{
										$coursename=$row['coursename'];
										$opendate=$row['opendate'];
										$opentime=$row['opentime'];
										$openday=$row['openday'];

		if ($row !== "" ) { @$no++; }

		$message .= '<tr>
                 <td style="font-size:11px;" align="center">'.$no.'</td>
		<td style="font-size:11px;" align="left">'.$coursename.'</td>
		<td style="font-size:11px;" align="center">'.$opendate.'</td>
		<td style="font-size:11px;" align="center">'.$opentime.'</td>
		<td style="font-size:11px;" align="center">'.$openday.'</td>
		</tr>';
	}
}

$message .='</table>';

$html = <<<HHHHHHHHHHHHHH
<html>
<body>
<div>$message</div>
</body>
</html>
HHHHHHHHHHHHHH;

$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("Arial","bold");
$canvas->page_text(571, 18, " {PAGE_NUM}", $font, 6, array(0,0,0));
$dompdf->stream("Report_Course_Year_Timetable_List.pdf");
?>
