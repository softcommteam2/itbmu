<?php
require_once('../connection/connection.php');
require_once("../function/config.php");
if(!isset($_SESSION["uid"]))
{
	echo '<script type="text/javascript">
		history.back();
		window.location.href="index.php?page=index";
		</script>';
}
$uid = $_SESSION['uid'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Tharavāda Buddhist Missionary University</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<?php require_once('header.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <div class="content"> 
      <h1>User List</h1>
      <div class="scrollable">
        <table>
          <thead>
            <tr style="font-size:12px;">
              <th align="center">User Name</th>
              <th align="center">User Type</th>
              <th align="center">Create Date</th>
              <th align="center">Last_at Date</th>
            </tr>
          </thead>
          <tbody>
            <?php
			$stmt = $itbmu->stmt_init();
		$stmt->prepare("SELECT user,usertype,createdate,lastindate FROM tbl_user");
		$stmt->execute() or die($stmt->error);
		$stmt->store_result();
		 $stmt->bind_result($user, $usertype,$createdate,$lastindate);
		while($stmt->fetch())
			{
                ?>
            <tr>
              <td><?php echo $user;?></td>
              <td><?php echo $usertype;?></td>
              <td align="center"><?php echo $createdate;?></td>
              <td align="center"><?php echo $lastindate;?></td>
            </tr>
            <?php
              } 
            ?>
          </tbody>
        </table>
      </div>
    </div>
    <!-- ################################################################################################ -->
    <!-- / main body -->
  </main>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<?php require_once('footer.php'); ?>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="../layout/scripts/jquery.min.js"></script>
<script src="../layout/scripts/jquery.backtotop.js"></script>
<script src="../layout/scripts/jquery.mobilemenu.js"></script>
<script src="../layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>